from logging.config import fileConfig
from logging import getLogger

from sqlalchemy import create_engine


def _checks(settings):
    return [
        ('OWNER', settings.db_owner, _user_exists),
        (' USER', settings.db_user, _user_exists),
        (' REPO', settings.db, _db_exists)
    ]


def creation_status(settings):
    with settings.most_elevated_connection(auto_commit=False) as conn:
        return {
            what: dict(value=value, check=check(conn, value))
            for what, value, check in _checks(settings)
            if value is not None
        }


def all_exists(settings):
    with settings.most_elevated_connection(auto_commit=False) as conn:
        for what, value, check in _checks(settings):
            # only check for things we have access to:
            if value and check(conn, value) is False:
                return False
        return True


def create_db(settings):
    with settings.admin_connection(auto_commit=True) as conn:
        db_owner = settings.db_owner
        db_owner_password = settings.REPO_DB_OWNER_PASSWORD
        db_name = settings.db
        db_user = db_name
        db_password = settings.REPO_DB_PASSWORD
        # create owner user/role
        if not _user_exists(conn, db_owner):
            conn.execute(
                f"CREATE USER {db_owner} PASSWORD '{db_owner_password}' CREATEROLE"
            )
        # create database
        if not _db_exists(conn, db_name):
            current_admin_user = conn.execute('SELECT USER').first()[0]
            conn.execute(
                f"GRANT {db_owner} TO {current_admin_user}"
            )
            conn.execute(f"CREATE DATABASE {db_name} WITH OWNER {db_owner}")
        # create database user/role
        if not _user_exists(conn, db_name):
            conn.execute(f"CREATE USER {db_user} PASSWORD '{db_password}'")

    with settings.owner_connection() as conn:
        conn.execute(f"CREATE SCHEMA IF NOT EXISTS repo")
        _grant_repo_usage(conn, db_user)


def _grant_repo_usage(conn, grantee=None):
    """(re-)grant read-only access to the repo schema."""
    conn.execute(f"GRANT USAGE ON SCHEMA repo TO {grantee}")
    conn.execute(f"GRANT SELECT ON ALL TABLES IN SCHEMA repo TO {grantee}")


def _revoke_repo_usage(conn, grantee=None):
    """revoke access to the repo schema."""
    conn.execute(f"REVOKE SELECT ON ALL TABLES IN SCHEMA repo FROM {grantee}")
    conn.execute(f"REVOKE USAGE ON SCHEMA repo from {grantee}")


def drop_db(settings):
    with settings.admin_connection(auto_commit=True) as conn:
        if _db_exists(conn, settings.db):
            conn.execute(f"DROP DATABASE {settings.db}")
        if _user_exists(conn, settings.db_user):
            conn.execute(f"DROP USER {settings.db_user}")
        if _user_exists(conn, settings.db_owner):
            conn.execute(f"DROP USER {settings.db_owner}")


def _user_exists(conn, user):
    return conn.execute(
        f"SELECT 1 FROM pg_catalog.pg_user WHERE usename = '{user}'"
    ).first() is not None


def _db_exists(conn, db_name):
    return conn.execute(
        f"SELECT 1 FROM pg_catalog.pg_database WHERE datname = '{db_name}'"
    ).first() is not None
