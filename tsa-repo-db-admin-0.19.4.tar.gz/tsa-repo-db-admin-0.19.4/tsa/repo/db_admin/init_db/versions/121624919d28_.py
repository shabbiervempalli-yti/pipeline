"""
Sets up a new multitenant repository database

Revision ID: 121624919d28
Revises:
Create Date: 2020-05-17 14:11:35.257485

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision = '121624919d28'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'library',
        sa.Column('id', postgresql.TEXT(), nullable=False,
                  comment='Id of the repository library. Normally the tenant id'),
        sa.Column('name', postgresql.TEXT(), nullable=True,
                  comment='Name of the repository library. Normally the tenant domain'),
        sa.Column('schema', postgresql.TEXT(), nullable=True, comment='Name of the repository schema'),
        sa.Column('target_revision', postgresql.TEXT(), nullable=True,
                  comment='Target alembic revision for this library.'),
        sa.Column('user_created', postgresql.TEXT(), nullable=False),
        sa.Column('timestamp_created', sa.TIMESTAMP(timezone=True), nullable=False),
        sa.Column('user_modified', postgresql.TEXT(), nullable=False),
        sa.Column('timestamp_modified', sa.TIMESTAMP(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )


def downgrade():
    op.drop_table(
        'library'
    )
