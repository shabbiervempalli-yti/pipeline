from datetime import datetime, timezone
from typing import Iterator, Union, Optional, Mapping, TypeVar
from dataclasses import dataclass, field
import logging

from sqlalchemy import create_engine
import sqlalchemy.orm as orm

from tsa.repo.api.admin import LibraryStatus
from tsa.repo.api.message import RepositoryNotFoundError
import tsa.repo.db_admin.command as admin_cmd
import tsa.repo.db_admin.init_db.command as repo_cmd

from .model import Library

logger = logging.getLogger(__name__)


def find_library(settings, id, include_counts=False) -> Optional[LibraryStatus]:
    """Lookup the library registration for this library, if it exists."""
    with settings.user_session(default_schema='repo') as sess:
        db_lib = _find_library(sess, id)
        return _with_status(sess, _map_db(settings, db_lib), include_counts) if db_lib else None


def find_or_create_library(settings, id, name=None, include_counts=False) -> LibraryStatus:
    if settings.db_owner:
        with settings.owner_session() as sess:
            db_lib = _find_library(sess, id)
            if db_lib is None:
                admin_cmd.CreateLibrary(settings, id=id, name=name).run()
                db_lib = _find_library(sess, id)
            return _with_status(sess, _map_db(settings, db_lib), include_counts)
    else:
        library = find_library(settings, id, include_counts=False)
        if library:
            return library
        raise RepositoryNotFoundError(
            f"Not Found: library '{id}', does not exist and cannot be created."
        )


def iter_library(settings, *id: str) -> Iterator[LibraryStatus]:
    """List Library registrations for the selected ids (default all) in a lazy iteration."""
    with settings.user_session(default_schema='repo') as sess:
        for lib in _iter_library(sess, *id):
            yield _map_db(settings, lib)


def _map_db(settings, db_lib: Library) -> LibraryStatus:
    return LibraryStatus(
        db=settings.db,
        id=db_lib.id,
        name=db_lib.name,
        schema=db_lib.schema,
        target_revision=db_lib.target_revision,
        user_created=db_lib.user_created,
        timestamp_created=db_lib.timestamp_created,
        user_modified=db_lib.user_modified,
        timestamp_modified=db_lib.timestamp_modified
    )


def _with_status(conn, library: LibraryStatus, include_counts=False) -> LibraryStatus:
    library.schema_exists = _schema_exists(conn, library.schema)
    library.revision = _library_revision(conn, library.schema) if library.schema_exists else None
    library.table_counts = _library_table_counts(conn, library.schema) if include_counts else None
    return library


def iter_library_status(settings, *id: str, include_counts=False) -> Iterator[LibraryStatus]:
    """List the status for the given (or all registered) libraries in a lazy iteration."""
    with settings.user_session(default_schema='repo') as sess:
        for lib in _iter_library(sess, *id):
            lib_status = _with_status(sess, _map_db(settings, lib), include_counts=include_counts)
            yield lib_status


def upsert_library(settings, id, name=None, schema=None, target_revision=None) -> LibraryStatus:
    """Create or update the name of a given library registration.
    Compare the creation and modification timestamp of the returned object to know the create/update case.
    """
    with settings.owner_session() as sess:
        lib = _find_library(sess, id)
        now = datetime.now(tz=timezone.utc)
        if not lib:
            lib = Library.create(
                id, user=settings.current_user, name=name,
                schema=schema, target_revision=target_revision, now=now
            )
            sess.add(lib)
        else:
            lib.name = name
            lib.target_revision = target_revision or lib.target_revision
            if schema is not None and schema != lib.schema:
                raise Exception(f"Cannot change schema for library '{lib.id}' from '{lib.schema}' to '{schema}'")
            lib.user_modified = settings.current_user
            lib.timestamp_modified = now
        sess.flush()
        if not _schema_exists(sess, lib.schema):
            _create_library_schema(sess, lib.schema, settings.db_user)
        return _with_status(sess, _map_db(settings, lib), include_counts=True)


def iter_delete_library(settings, *id: str) -> Iterator[LibraryStatus]:
    """
     Delete schema and registration for the given library ids (default all registered libraries)
     in lazy iteration.
     Returns the Library object (if deleted) or the schema id (if only schema could be deleted).
    """
    deleted_ids = []
    registered_libs = list(iter_library_status(settings, *id))

    for lib in registered_libs:
        deleted = False
        with settings.owner_connection(auto_commit=True) as conn:
            if _schema_exists(conn, lib.schema):
                _drop_library_schema(conn, lib.schema, settings.db_user)
                deleted_ids.append(lib.schema)
                deleted = True
        with settings.owner_session() as sess:
            db_lib = _find_library(sess, lib.id)
            sess.delete(db_lib)
            deleted_ids.append(lib.id)
            deleted = True
        if deleted:
            yield _with_status(sess, lib, include_counts=False)
    for lib_id in id:
        if lib_id not in deleted_ids:
            # a schema or id that has lost its registration
            # try to delete as schema
            missing_lib = Library.create(lib_id, '<missing>', settings.current_user)
            with settings.owner_connection(auto_commit=True) as conn:
                if _schema_exists(conn, missing_lib.schema):
                    _drop_library_schema(conn, missing_lib.schema, settings.db_user)
                    yield _with_status(sess, _map_db(settings, missing_lib), include_counts=False)


def _iter_library(session, *id) -> Iterator[Library]:
    query = session.query(Library)
    if id:
        query = query.filter(Library.id.in_(id))
    for library in query:
        yield library


def _find_library(session, id):
    return session.query(Library).filter(Library.id == id).one_or_none()


def _schema_exists(conn, schema):
    return conn.execute(
        f"SELECT 1 FROM pg_catalog.pg_namespace WHERE nspname='{schema}'"
    ).first() is not None


def _role_exists(conn, role):
    return conn.execute(
        f"SELECT 1 FROM pg_catalog.pg_roles WHERE rolname='{role}'"
    ).first() is not None


def _alembic_exists(conn, schema):
    return conn.execute(
        f"SELECT 1 FROM pg_catalog.pg_tables WHERE schemaname='{schema}' AND tablename='alembic_version'"
    ).first() is not None


def _library_revision(conn, schema):
    if _alembic_exists(conn, schema):
        return conn.execute(
            f"SELECT version_num FROM {schema}.alembic_version"
        ).scalar()
    return None


def _library_table_counts(conn, schema):
    return {
        table: conn.execute(f"SELECT count(*) FROM {schema}.{table}").scalar()
        for (table, ) in conn.execute(
            f"SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname='{schema}' AND tablename != 'alembic_version'"
        )
    }


def _grant_library_usage(conn, schema, grantee=None):
    """(re-)grant relevant access to the library schema to a user role."""
    # if grantee is missing, use the library role with the name of the schema
    library_role = schema
    grantee = grantee or library_role
    conn.execute(f"GRANT USAGE ON SCHEMA {schema} TO {grantee}")
    conn.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA {schema} TO {grantee}")
    if _alembic_exists(conn, schema):
        conn.execute(f"REVOKE INSERT, UPDATE, DELETE ON {schema}.alembic_version FROM {grantee}")
    repo_cmd._grant_repo_usage(conn, grantee)


def _revoke_library_usage(conn, schema, grantee=None):
    """revoke all user access to a library and repo schema."""
    # if grantee is missing, use the library role with the name of the schema
    library_role = schema
    grantee = grantee or library_role
    repo_cmd._revoke_repo_usage(conn, grantee)
    conn.execute(f"REVOKE ALL ON ALL TABLES IN SCHEMA {schema} FROM {grantee}")
    conn.execute(f"REVOKE USAGE ON SCHEMA {schema} FROM {grantee}")


def _create_library_schema(conn, schema, grantee=None):
    conn.execute(f"CREATE SCHEMA {schema}")
    library_role = schema
    if not _role_exists(conn, library_role):
        conn.execute(f"CREATE ROLE {library_role}")
    _grant_library_usage(conn, schema, library_role)
    if grantee:
        conn.execute(f"GRANT {library_role} TO {grantee}")


def _drop_library_schema(conn, schema, grantee=None):
    library_role = schema
    library_role_exists = _role_exists(conn, library_role)
    if library_role_exists:
        if grantee:
            conn.execute(f"REVOKE {library_role} FROM {grantee}")
        _revoke_library_usage(conn, schema, library_role)
    conn.execute(f"DROP SCHEMA {schema} CASCADE")
    if library_role_exists:
        try:
            conn.execute(f"DROP ROLE {library_role}")
        except Exception as e:
            logger.warning(f"Could not delete ROLE '{library_role}'. Maybe another database on this server uses it?")
