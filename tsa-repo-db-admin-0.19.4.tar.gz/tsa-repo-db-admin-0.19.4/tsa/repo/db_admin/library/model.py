from typing import Optional
from datetime import datetime, timezone
import uuid

from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import as_declarative, declared_attr


@as_declarative()
class Base:
    pass


def normalize_schema_name(input: str):
    input = input.strip()
    # convert tenant UUID to an allowed database schema name
    input = input.replace('-', '')
    if input[0].isnumeric():
        input = '_' + input
    return input


class Library(Base):
    __tablename__ = 'library'
    id = Column(String, primary_key=True, unique=True, nullable=False)
    name = Column(String, nullable=False)
    schema = Column(String, nullable=False)
    target_revision = Column(String, nullable=True, default='head')
    user_created = Column(String, nullable=False)
    timestamp_created = Column(DateTime, nullable=False)
    user_modified = Column(String, nullable=False)
    timestamp_modified = Column(DateTime, nullable=False)

    @classmethod
    def create(cls, id, user, name=None, schema=None, now=None, target_revision=None, **kwargs):
        now = now or datetime.now(tz=timezone.utc)
        name = name or id
        schema_name = schema or normalize_schema_name(id)
        return Library(
            id=id,
            name=name,
            schema=schema_name,
            target_revision=target_revision or 'head',
            user_created=user,
            user_modified=user,
            timestamp_created=now,
            timestamp_modified=now
        )
