"""
Revision ID: 3f0bac90d7cd
Revises: 9925f23744f4
Create Date: 2020-05-12 16: 29: 01.925531

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision = '3f0bac90d7cd'
down_revision = '9925f23744f4'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'object_link',
        sa.Column('object_uuid', postgresql.UUID(), nullable=False),
        sa.Column('rel', postgresql.TEXT(), nullable=False),
        sa.Column('ref', postgresql.TEXT(), nullable=True),

        sa.Column('user_created', postgresql.TEXT(), nullable=False),
        sa.Column('timestamp_created', sa.TIMESTAMP(timezone=True), nullable=False),
        sa.Column('user_modified', postgresql.TEXT(), nullable=False),
        sa.Column('timestamp_modified', sa.TIMESTAMP(timezone=True), nullable=False),
    )

    op.create_primary_key(None, 'object_link', ['object_uuid', 'rel', 'ref'])
    op.create_foreign_key(None, 'object_link', 'object', ['object_uuid'], ['uuid'])
    op.create_foreign_key(None, 'object_link', 'path', ['rel'], ['path'])
    op.create_foreign_key(None, 'object_link', 'path', ['ref'], ['path'], deferrable=True)
    op.create_index(None, 'object_link', ['ref', 'rel'])

    op.create_table(
        'path_link',
        sa.Column('sub', postgresql.TEXT(), nullable=False),
        sa.Column('rel', postgresql.TEXT(), nullable=False),
        sa.Column('ref', postgresql.TEXT(), nullable=True),

        sa.Column('user_created', postgresql.TEXT(), nullable=False),
        sa.Column('timestamp_created', sa.TIMESTAMP(timezone=True), nullable=False),
        sa.Column('user_modified', postgresql.TEXT(), nullable=False),
        sa.Column('timestamp_modified', sa.TIMESTAMP(timezone=True), nullable=False),
    )

    op.create_primary_key(None, 'path_link', ['sub', 'rel', 'ref'])
    op.create_foreign_key(None, 'path_link', 'path', ['sub'], ['path'])
    op.create_foreign_key(None, 'path_link', 'path', ['rel'], ['path'])
    op.create_foreign_key(None, 'path_link', 'path', ['ref'], ['path'], deferrable=True)
    op.create_index(None, 'path_link', ['ref', 'rel'])


def downgrade():
    op.drop_table('path_link')
    op.drop_table('object_link')
