from abc import ABC, abstractmethod, abstractproperty
from dataclasses import fields
from typing import Union, List, Sequence, Mapping, Any, Callable, Type, TYPE_CHECKING, cast
from pathlib import Path

from alembic.config import Config
import alembic.command as alembic_commands

import tsa.repo.db_admin.init_db.command as create_db_commands
import tsa.repo.db_admin.library.command as library_commands
from tsa.repo.api.admin import LibraryStatus


def _lookup_alembic_command(cmd: str) -> Callable:
    return cast(Callable, staticmethod(getattr(alembic_commands, cmd)))


class Command(ABC):
    name: str = ''
    args: List[Mapping[str, Any]] = []

    def __init__(self, settings):
        self.settings = settings

    @abstractmethod
    def run(self): ...


class AlembicCommand(Command):
    alembic_config: str
    alembic_command: Callable[..., Any]
    alembic_args: Mapping[str, Any] = {}

    def run(self):
        self.do_alembic()

    def do_alembic(self, attributes=None):
        base_path = Path(__file__).parent
        alembic_config_path = (base_path / self.alembic_config).resolve()
        alembic_script_location = str(Path(alembic_config_path).parent)
        alembic_cfg = Config(alembic_config_path)
        alembic_cfg.attributes['settings'] = self.settings
        if attributes:
            alembic_cfg.attributes.update(attributes)
        alembic_cfg.set_main_option('script_location', alembic_script_location)
        self.alembic_command(alembic_cfg, **self.alembic_args)


class AlembicInitDbCommand(AlembicCommand):
    alembic_config = "init_db/alembic.ini"


class ShowConfig(Command):
    """Show connection settings"""
    name = 'settings'
    args = [
        dict(name='property', description='the settings attribute to show (default all).', nargs='?')
    ]

    def __init__(self, settings, property=None):
        super().__init__(settings)
        self.property = property

    def run(self):
        if self.property:
            print(getattr(self.settings, self.property))
        else:
            print(self.settings)


class ShowDatabase(AlembicInitDbCommand):
    """Report the creation and migration status of the repo schema"""
    name = 'dbstatus'
    alembic_command: Callable = _lookup_alembic_command('current')

    def run(self):
        _print_feedback('repo database status')
        db_status = create_db_commands.creation_status(self.settings)
        print('\n'.join(
            f"{what}{'' if status['check'] else ' MISSING'}: {status['value']}"
            for what, status in db_status.items()
        ))
        if create_db_commands.all_exists(self.settings):
            self.do_alembic()


class UpgradeDatabase(AlembicInitDbCommand):
    """Upgrade the repo schema (library bookkeeping) """
    name = 'upgradedb'
    alembic_command = _lookup_alembic_command('upgrade')
    alembic_args = dict(revision='head')


class AlembicDatabase(AlembicInitDbCommand):
    """Execute an alembic command on the repo schema"""
    name = 'alembicdb'
    args = [
        dict(
            name='alembic_cmd',
            description='the alembic command',
            nargs=1,
            choices=('current', 'branches', 'heads', 'history')  # show (needs arg)
        )
    ]

    def __init__(self, settings, alembic_cmd):
        super().__init__(settings)
        cmd = _as_list_of_strings(alembic_cmd)[0]
        self.alembic_command = getattr(alembic_commands, cmd)


class CreateDatabase(Command):
    """Create a new repository database (if not existing)"""
    name = 'createdb'

    def run(self):
        if create_db_commands.all_exists(self.settings):
            print('Already exists')
        else:
            create_db_commands.create_db(self.settings)
            UpgradeDatabase(self.settings).run()
        ShowDatabase(self.settings).run()


def create_db(settings):
    CreateDatabase(settings).run()
    return create_db_commands.all_exists(settings)


class DropDatabase(Command):
    """Drop the complete repository database"""
    name = 'dropdb'

    def run(self):
        for lib_deleted in library_commands.iter_delete_library(self.settings):
            print(f"Repo library '{lib_deleted.id}' (database schema '{lib_deleted.schema}') deleted.")
        create_db_commands.drop_db(self.settings)
        ShowDatabase(self.settings).run()


class RepoCommand(Command):
    def run(self):
        if not create_db_commands.all_exists(self.settings):
            _print_error(f"Repository database '{self.settings.REPO_DB}' is not initialized correctly.")
            return
        self.do_repo()

    @abstractmethod
    def do_repo(self): ...


class AlembicLibraryCommand(AlembicCommand):
    """Execute any alembic command agaist the specified libaries"""
    alembic_config = "library/alembic.ini"
    args = [
        dict(name='ids', description='the ids for the library.', nargs='*'),
        dict(name='alembic_cmd', description='an alembic command.', nargs=1)
    ]
    safe = True

    def __init__(self, settings, ids, alembic_cmd):
        super().__init__(settings)
        library_ids = _as_list_of_strings(ids)
        self.library_ids = library_ids
        cmd = _as_list_of_strings(alembic_cmd)[0]
        self.alembic_command = getattr(alembic_commands, cmd)

    def run(self):
        if not create_db_commands.all_exists(self.settings):
            _print_error(f"Repository database '{self.settings.REPO_DB}' is not initialized correctly.")
        else:
            _print_feedback(f"alembic '{self.alembic_command.__name__}' for '{self.library_ids}'")
            self.do_alembic(dict(library_ids=self.library_ids))


class LibraryCommand(RepoCommand):
    args: List[Mapping[str, Any]] = [
        dict(name='ids', description='the id for the library.', nargs='*')
    ]
    safe = True
    include_counts = False

    def __init__(self, settings, ids):
        super().__init__(settings)
        self.library_ids = _as_list_of_strings(ids)

    def do_repo(self):
        for id in self.library_ids:
            library = library_commands.find_library(self.settings, id, include_counts=self.include_counts)
            self.do_library(id, library)
        if not self.library_ids and self.safe:
            for library in library_commands.iter_library_status(self.settings, include_counts=self.include_counts):
                self.do_library(library.id, library)

    @abstractmethod
    def do_library(self, id, library): ...


class UpgradeLibrary(LibraryCommand):
    """Upgrade library schemas to the target revision specified in the repo.library table"""
    name = 'upgrade'

    def do_library(self, id, library):
        current_revision = library.revision
        revision_command = AlembicLibraryCommand(self.settings, [id], self.name)
        revision_command.alembic_args = dict(revision=library.target_revision)
        revision_command.run()
        library = library_commands.find_library(self.settings, id)
        _print_feedback(f"repo library {id} {self.name}d from {current_revision} to {library.revision}")


class DowngradeLibrary(UpgradeLibrary):
    """Downgrade library schemas to the target revision specified in the repo.library table"""
    name = 'downgrade'


class AlembicEachLibrary(LibraryCommand):
    """Execute an alembic command"""
    name = 'alembic'
    args = [
        dict(
            name='alembic_cmd',
            description='the alembic command',
            nargs=1,
            choices=('current', 'branches', 'heads', 'history')  # show (needs arg)
        ),
        dict(name='ids', description='one or more library ids.', nargs='*'),
    ]

    def __init__(self, settings, alembic_cmd, ids):
        super().__init__(settings, ids)
        self.alembic_cmd = _as_list_of_strings(alembic_cmd)[0]

    def do_library(self, id, library):
        AlembicLibraryCommand(self.settings, [id], self.alembic_cmd).run()


class DropLibrary(LibraryCommand):
    """Delete the library schema for the give library"""
    name = 'drop'
    safe = False

    def do_library(self, id, library):
        delete_count = 0
        for library in library_commands.iter_delete_library(self.settings, id):
            delete_count += 1
            _print_feedback(f"Repo library '{library.id}' (database schema '{library.schema}') deleted")
        if delete_count == 0:
            _print_feedback(f"Repo library '{id}' NOT FOUND")


class ListLibrary(LibraryCommand):
    """List the status of the for the given libraries"""
    name = 'list'

    def do_repo(self):
        _print_header(LibraryStatus)
        super().do_repo()

    def do_library(self, id, library):
        _print_row(library)


class SetRevisionTarget(LibraryCommand):
    """Set the target revision of one or more libraries"""
    name = 'target'
    args = [
        dict(name='revision', description='the target revision', nargs=1),
        dict(name='ids', description='one or more library ids.', nargs='*'),
    ]

    def __init__(self, settings, revision, ids):
        super().__init__(settings, ids)
        self.revision = _as_list_of_strings(revision)[0]

    def do_library(self, id, library):
        current_target = library.target_revision
        library = library_commands.upsert_library(self.settings, id, target_revision=self.revision)
        _print_feedback(
            f"target revision for library {id} changed " +
            f"from {current_target} to {library.target_revision} [current {library.revision}]"
        )


class ShowLibrary(LibraryCommand):
    """Show the staticistics for the given libraries"""
    name = 'show'
    include_counts = True

    def do_library(self, id, library):
        _print_feedback(f"library {library.id}")
        for f in fields(library):
            if f.name != 'table_counts':
                print(f"{f.name:20}: {getattr(library, f.name)}")
        print('table row counts')
        for table, count in library.table_counts.items():
            print(f"  {table:18}: {count}")


class CreateLibrary(RepoCommand):
    """Create a (tenant) library in the respository"""
    name = 'create'
    args = [
        dict(
            name='id',
            description='the id for the library, for tenant libraries this is the domain name.',
            nargs=1
        ),
        dict(
            name='name',
            description='the name for the library, for tenant libraries this is the domain name.',
            nargs='?'
        )
    ]

    def __init__(self, settings, id, name=None):
        super().__init__(settings)
        self.library_id = _as_list_of_strings(id)[0]
        self.library_name = _as_list_of_strings(name)[0] if name else self.library_id

    def do_repo(self):
        library = library_commands.upsert_library(
            self.settings,
            id=self.library_id, name=self.library_name,
            target_revision=self.settings.DEFAULT_REVISION
        )
        new = library.timestamp_created == library.timestamp_modified
        _print_feedback(f"repo library { 'created' if new else 'updated' }")
        UpgradeLibrary(self.settings, self.library_id).run()
        ListLibrary(self.settings, self.library_id).run()


# TODO use `tabulate` instead of these _print methods


def _print_feedback(message):
    print(f"== {message}")


def _print_error(message):
    print(f"!! {message}")


def _print_header(dataclass_class):
    print('| ' + ' | '.join(
        f"{name[:width]:^{width}}"
        for f in fields(dataclass_class)
        for name, width in ((f.name, f.metadata['width']), )
        if f.repr
    ) + ' |')
    print('|-' + '-|-'.join(
        '-' * f.metadata['width']
        for f in fields(dataclass_class)
        if f.repr
    ) + '-|')


def _print_row(data_obj):
    print('| ' + ' | '.join(
        f"{value[:width]:{width}}"
        for f in fields(data_obj)
        for value, width in ((str(getattr(data_obj, f.name)), f.metadata['width']), )
        if f.repr
    ) + ' |')


def _as_list_of_strings(input: Union[None, str, Sequence[str]]) -> List[str]:
    if input is None:
        return []
    if isinstance(input, str):
        return [input]
    return list(input)


LIBRARY_PRINT_ATTRS = ['id', 'name']
COMMAND_CLASSES: List[Type[Command]] = [
    ShowConfig,
    ShowDatabase, CreateDatabase, DropDatabase, UpgradeDatabase,
    ShowLibrary, ListLibrary, CreateLibrary, DropLibrary,
    SetRevisionTarget, UpgradeLibrary, DowngradeLibrary,
    # AlembicLibraryCommand,
    AlembicEachLibrary,
    AlembicDatabase
]
commands = {
    c.name: c for c in COMMAND_CLASSES
}
