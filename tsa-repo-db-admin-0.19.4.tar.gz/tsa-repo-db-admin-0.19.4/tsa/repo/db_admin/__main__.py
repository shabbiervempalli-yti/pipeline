__doc__ = """
TODO: automate the following:

( as super-user, normally outside provisioning)
* create a new repo_admin
 * `CREATE USER :repo_admin PASSWORD :repo_admin_password CREATEDB CREATEROLE`

( as repo_admin )
* create a new repository database
   * create a repository owner
        `CREATE USER :repo_owner PASSWORD :repo_owner_password CREATEROLE`
   * (optional) create a tablespace
        `CREATE TABLESPACE :repo_tablespace OWNER = :repo_owner LOCATION = :repo_tablespace_location`
   * create the repository database
        `CREATE DATABASE :repo_name WITH OWNER = :repo_owner TABLESPACE = :repo_tablespace`
   * create the repo user :repo_user with read-write access to the 'libraries' schema
        `CREATE USER :repo_user PASSWORD :repo_user_password`

( as repo_owner)
* initialize the 'libraries' schema
   * create the 'libraries' schema
        `CREATE SCHEMA libraries`

   * initialize the libraries schema (table with list of libraries and their target migration status)
        `create table library (id text, name text, target_migration text)`
        `GRANT SELECT ON ALL TABLES IN SCHEMA libraries TO :repo_user`


* create and register a library :library_id, :library_name (e.g tenant_id and domain name)
   * create schema and a role with access to it (both :library_id )
        `CREATE SCHEMA :library_id`
        `CREATE ROLE :library_id`
        `GRANT :library_id TO :repo_user NOINHERIT
        `GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA :library_id TO :library_id`
   * register in 'libraries'
        `INSERT INTO libraries.library (id, name) VALUES (:library_id, :library_name)`

( as repo_owner)
* for one or all libraries: (as registered in libraries.library)
   * initialize alembic (creates a migration table if needed)
   * asserts the migration status (alembic vs target in libraries.library)
   * set the migration status in libraries.library
   * execute upgrades/downgrades (alembic)

( as repo_user)
* list current libraries
* check exisitence of a library
* provide summary stats of a library (using SET ROLE :library_id)

"""

import argparse
import logging
import sys
from .settings import RepoDbArgumentParser, AccessNotConfiguredError


if __name__ == '__main__':
    logging.basicConfig()
    parser = RepoDbArgumentParser()
    settings = parser.settings()
    if settings:
        for c in settings.iter_commands():
            try:
                c.run()
            except AccessNotConfiguredError as e:
                sys.exit(str(e))
