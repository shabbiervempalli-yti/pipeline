import os
import pwd
import argparse
import re
from typing import Optional, Sequence, Iterator
from functools import lru_cache
from contextlib import contextmanager

import sqlalchemy.orm as orm
from sqlalchemy import create_engine
from sqlalchemy.engine import Connection

from .command import commands as admin_commands, Command

ENV_KEYS = {
    'REPO_DB_SERVER': dict(
        description='host and port for the postgresql server',
        arg='server',
        short_arg='s'
    ),
    'REPO_DB_ADMIN': dict(
        description='postgresql user (and password) that can create database and users.',
        arg='admin',
        password='REPO_DB_ADMIN_PASSWORD'
    ),
    'REPO_DB_ADMIN_PASSWORD': dict(
        description='password for the REPO_DB_ADMIN user',
        obfuscated='*******'
    ),
    'REPO_DB_OWNER': dict(
        description='postgresql user (and password) that owns the repository schemas and can execute DDL.',
        arg='owner',
        password='REPO_DB_OWNER_PASSWORD'
    ),
    'REPO_DB_OWNER_PASSWORD': dict(
        description='password for the REPO_DB_OWNER user',
        obfuscated='*******'
    ),
    'REPO_DB':  dict(
        description='name of the repository database, and postgresql ' +
        'user (and password) that has DML access to the repository schemas.',
        arg='db',
        password='REPO_DB_PASSWORD'
    ),
    'REPO_DB_PASSWORD':  dict(
        description='password for the REPO_DB user',
        obfuscated='*******'
    ),
    'REPO_DB_ADMIN_DB': dict(
        description='default database for the admin account.',
        default='postgres',
        arg='admindb',
        short_arg='p',
        required=False
    ),
    'USER': dict(
        description='user name used in DML statements',
        arg='user',
        required=False
    ),
    'LIBRARIES':  dict(
        description='restrict all operations to the following libraries, first library is default library',
        arg='lib',
        required=False
    ),
    'GLOBAL_LIBRARY': dict(
        description='name of shared, readonly global library',
        arg='global_lib',
        required=False,
        default='global'
    ),
    'DEFAULT_REVISION': dict(
        description='default target schema revision for new libraries',
        arg='target_revision',
        default='head',
        required=False
    ),
    'ECHO_SQL': dict(
        description='echo all sql to logging',
        arg='echo_sql',
        short_arg='v',
        type=lambda v: v and v[0].lower() in ('y', 't'),
        default=False,
        required=False
    )
}


class AccessNotConfiguredError(Exception):
    pass


class SplitPassword(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        pwd_dest = ENV_KEYS.get(self.dest).get('password')
        if pwd_dest and ':' in values:
            user, password = values.split(':')
            setattr(namespace, self.dest, user)
            setattr(namespace, pwd_dest, password)
        else:
            setattr(namespace, self.dest, values)


class RepoDbArgumentParser(argparse.ArgumentParser):
    def __init__(self):
        super().__init__(prog='db_admin', description="Administer the tsa respository database")
        for key, config in ENV_KEYS.items():
            if config.get('arg'):
                description = config.get('description', '')
                if 'default' in config:  # do not use default mechanism of argparse, too early in defaulting
                    description += f" (default '{config.get('default')}')'"
                self.add_argument(
                    '-' + config.get('short_arg', config['arg'][0]),
                    '--' + config['arg'],
                    dest=key,
                    action=SplitPassword,
                    help=description,
                    type=config.get('type', str)
                )
        self.add_argument(
            '-f',
            '--envfile',
            dest='settings_file',
            help='Read environment settings from a file. Suppresses to read from environment variables.'
        )
        self.add_argument(
            '-e',
            '--fromenv',
            dest='env_settings',
            action='store_true',
            help='This flags forces to also read environment variable, even if --envfile is set/'
        )
        sub_parsers = self.add_subparsers(
            title='repo admin commands',
            help='commands to execute',
            dest='cmd',
            parser_class=argparse.ArgumentParser
        )
        for key, cmd in admin_commands.items():
            cmd_sub_parser = sub_parsers.add_parser(
                key,
                help=cmd.__doc__ or '',
                description=cmd.__doc__ or None
            )
            if cmd.args:
                for arg in cmd.args:
                    cmd_sub_parser.add_argument(
                        dest=arg.get('name'),
                        nargs=arg.get('nargs', 1),
                        help=arg.get('description'),
                        choices=arg.get('choices')
                    )

    def settings(self):
        args = self.parse_args()
        if args.cmd is None:
            self.print_help()
            return None
        sources = [vars(args)]
        if args.settings_file:
            sources.append(_vars_from_file(args.settings_file))
        if not args.settings_file or args.env_settings:
            sources.append(os.environ)
        return Settings(*sources)


class Settings:

    def __init__(self, *source):
        self._sources = source or [os.environ]

    def __getattr__(self, name):
        if name in ENV_KEYS:
            return self._get_setting(name)
        raise AttributeError(f"Unsupported key for settings: '{name}'")

    def _get_setting(self, key, default=None, obfuscate=False):
        env_setting = ENV_KEYS.get(key, None)
        obfuscated_value = obfuscate and env_setting and env_setting.get('obfuscated', None)
        value = None
        for source in self._sources:
            value = source.get(key, None)
            if value is not None:
                if env_setting and 'type' in env_setting:
                    value = env_setting['type'](value)
                return obfuscated_value or value
        if default is not None:
            return obfuscated_value or default
        if env_setting:
            if 'default' in env_setting:
                return obfuscated_value or env_setting.get('default')
            if env_setting.get('required', True):
                raise AttributeError(f"Not set: [{key}] {env_setting.get('description')}")
        return obfuscated_value or None

    @property
    def selected_libraries(self) -> Sequence[str]:
        """Return a list of library id to filter operations on (or none)"""
        libs = self.LIBRARIES
        if libs is None:
            return []
        if isinstance(libs, str):
            return [lib.strip() for lib in libs.split(',')]
        return libs

    @property
    def default_library(self) -> str:
        """Returns the default library: first item in LIBRARIES or the global library"""
        libs = self.selected_libraries
        return libs[0] if libs else self.GLOBAL_LIBRARY

    @property
    def current_user(self):
        return self.USER or pwd.getpwuid(os.getuid())[0]

    @property
    def db_owner(self):
        return self._get_setting('REPO_DB_OWNER', False) or None

    @property
    def db_admin(self):
        return self._get_setting('REPO_DB_ADMIN', False) or None

    @property
    def db(self):
        try:
            return self.REPO_DB
        except AttributeError as e:
            raise AccessNotConfiguredError(
                f"Sorry: database access not configured. {e}"
            )

    @property
    def db_user(self):
        return self.db

    @property
    def db_url(self):
        try:
            return f"postgresql://{self.REPO_DB_SERVER}/{self.REPO_DB}"
        except AttributeError as e:
            raise AccessNotConfiguredError(
                f"Sorry: database access not configured. {e}"
            )

    @property
    def admin_db_url(self):
        try:
            return (
                f"postgresql://{self.REPO_DB_ADMIN}:{self.REPO_DB_ADMIN_PASSWORD}" +
                f"@{self.REPO_DB_SERVER}/{self.REPO_DB_ADMIN_DB}"
            )
        except AttributeError as e:
            raise AccessNotConfiguredError(
                f"Sorry: database admin access not configured. {e}"
            )

    @property
    def owner_db_url(self):
        try:
            return (
                f"postgresql://{self.REPO_DB_OWNER}:{self.REPO_DB_OWNER_PASSWORD}" +
                f"@{self.REPO_DB_SERVER}/{self.REPO_DB}"
            )
        except AttributeError as e:
            raise AccessNotConfiguredError(
                f"Sorry: database owner access not configured. {e}"
            )

    @property
    def user_db_url(self):
        try:
            return (
                f"postgresql://{self.REPO_DB}:{self.REPO_DB_PASSWORD}" +
                f"@{self.REPO_DB_SERVER}/{self.REPO_DB}"
            )
        except AttributeError as e:
            raise AccessNotConfiguredError(
                f"Sorry: database user access not configured. {e}"
            )

    @lru_cache()
    def engine(url, echo_sql=False):
        return create_engine(url, echo=echo_sql)

    @lru_cache()
    def session_maker(url, echo_sql=False):
        return orm.sessionmaker(Settings.engine(url, echo_sql))

    @contextmanager
    def db_session(self, url, default_schema=None, expire_on_commit=False) -> Iterator[orm.Session]:
        # pylint: disable=no-member
        session = Settings.session_maker(url, self.ECHO_SQL)()
        session.expire_on_commit = expire_on_commit
        try:
            if default_schema:
                session.execute(f"SET search_path TO {default_schema}")
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            raise
        finally:
            session.close()

    def user_session(self, default_schema) -> Iterator[orm.Session]:
        return self.db_session(self.user_db_url, default_schema=default_schema)

    def owner_session(self, schema='repo') -> Iterator[orm.Session]:
        return self.db_session(self.owner_db_url, default_schema=schema)

    @contextmanager
    def db_connection(self, url, default_schema=None, auto_commit=False) -> Iterator[Connection]:
        with Settings.engine(url, self.ECHO_SQL).connect() as conn:
            if default_schema:
                conn.execute(f"SET search_path TO {default_schema}")
            if auto_commit:
                conn.execution_options(isolation_level='AUTOCOMMIT')
                yield conn
            else:
                with conn.begin():
                    yield conn

    def admin_connection(self, default_schema=None, auto_commit=True) -> Iterator[Connection]:
        return self.db_connection(self.admin_db_url, default_schema, auto_commit)

    def owner_connection(self, default_schema=None, auto_commit=False) -> Iterator[Connection]:
        return self.db_connection(self.owner_db_url, default_schema, auto_commit)

    def user_connection(self, default_schema=None, auto_commit=False) -> Iterator[Connection]:
        return self.db_connection(self.user_db_url, default_schema, auto_commit)

    def most_elevated_connection(self, default_schema=None, auto_commit=False) -> Iterator[Connection]:
        if self.db_admin:
            conn_factory = self.admin_connection
        elif self.db_owner:
            conn_factory = self.owner_connection
        elif self.db_user:
            conn_factory = self.user_connection
        else:
            raise AccessNotConfiguredError(f"Sorry: no access for '{self.db}' at '{self.REPO_DB_SERVER}' configured")
        return conn_factory(default_schema, auto_commit)

    def iter_commands(self) -> Iterator[Command]:
        cmds = self._get_setting('cmd', 'settings')
        if isinstance(cmds, str):
            yield self.create_command(cmds)
        else:
            for cmd in cmds:
                yield self.create_command(cmd)

    def create_command(self, cmd):
        command_class = admin_commands[cmd]
        args = [
            arg_setting if nargs == 1 else arg_setting
            for arg in command_class.args
            for arg_name, default, nargs in ((arg['name'],  arg.get('default', None), arg.get('nargs', 1)), )
            for arg_setting in (self._get_setting(arg_name, default), )
            if arg_setting is not None
        ]
        return command_class(self, *args)

    def __repr__(self):
        return '\n'.join(f"{key}={self._get_setting(key, '<not set>', obfuscate=False)}" for key in ENV_KEYS)

    def __str__(self):
        return '\n'.join(f"{key}={self._get_setting(key, '<not set>', obfuscate=True)}" for key in ENV_KEYS)


def _vars_from_file(envvar_file):
    with open(envvar_file) as env_var_lines:
        return {
            match.group(1): match.group(2)
            for env_var_line in env_var_lines
            # key = value with whitespace removed
            for match in (re.match(r'^\s*(\S+)\s*=\s*(\S*)\s*(#.*)?', env_var_line), )
            if not re.match(r'^\s*#', env_var_line)  # no comments
            if match is not None
        }


def settings_from_file(envvar_file, *other_sources):
    return Settings(_vars_from_file(envvar_file), *other_sources)


def settings_from_file_and_env(envvar_file):
    return Settings(_vars_from_file(envvar_file), os.environ)


def settings_from_env_and_file(envvar_file):
    return Settings(os.environ, _vars_from_file(envvar_file))


def settings_from_env():
    return Settings(os.environ)
