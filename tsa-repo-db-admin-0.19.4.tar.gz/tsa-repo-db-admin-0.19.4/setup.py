
from setuptools import setup, find_namespace_packages
import versioneer

setup(
    name='tsa-repo-db-admin',
    version=versioneer.get_version(),
    cmdclass=versioneer.get_cmdclass(),
    description='Time series analytics repository database admin tool',
    url='https://github.com/waylayio/TS_Analytics.git',
    author='Sander Vanhove, Sam Persoon, Thomas De Smedt',
    author_email='sander.vanhove@waylay.io, sam.persoon@waylay.io, thomas@waylay.io',
    packages=find_namespace_packages(include=['tsa.repo.*']),
    package_data={"tsa.repo.db_admin": ["py.typed"]},
    include_package_data=True,
    install_requires=[
        'tsa-repo-api',
        'psycopg2-binary; platform_system == "Darwin"',
        'psycopg2; platform_system == "Linux"',
        'sqlalchemy',
        'alembic'
    ],
    extras_require={
        'dev': [
            'sqlalchemy-stubs',
            'pgcli'
        ]
    },
    setup_requires=[
        'setuptools-pep8'
    ]
)
