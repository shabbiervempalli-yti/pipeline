

import functools
import inspect
from abc import abstractproperty
from datetime import datetime, tzinfo, timezone
from dataclasses import dataclass, asdict, field
from contextlib import ContextDecorator, contextmanager
from typing import (
    Any,
    Iterator,
    List,
    Dict,
    Mapping,
    Optional,
    Sequence,
    Tuple,
    Type,
    cast,
)
from http import HTTPStatus
import re
import uuid

import sqlalchemy.orm as orm
import sqlalchemy.orm.exc as orm_exc
import sqlalchemy.exc as sql_exc
from sqlalchemy import func

from tsa.repo.api.message import (
    ResultListener, ListenerSource, NOOP_LISTENER,
    RepositoryError, RepositoryDbError
)
from tsa.repo.api.standard import RELATIONS
from tsa.repo.api.admin import LibraryStatus
import tsa.repo.api as api
import tsa.repo.api.json as api_json
import tsa.repo.api.predicate as api_pred
import tsa.repo.api.standard as api_std
import tsa.repo.api.qdsl as api_qdsl

from . import model as db
from . import query as db_pred

UNKNOWN_USER = '<UNKNOWN>'
DEFAULT_LIMIT = 10


class AttrDict(dict):
    def __init__(self, *args, **kwargs):
        super(AttrDict, self).__init__(*args, **kwargs)
        self.__dict__ = self


class NoException(Exception):
    pass


# TODO : use @contextmanager
class wrap_sql_exceptions(ContextDecorator, ListenerSource):
    def __init__(self, *ignored, listener: ResultListener = None):
        self.ignored = ignored or NoException
        self.listener = listener or NOOP_LISTENER

    def __enter__(self):
        pass

    def __exit__(self, exc_type, exc_val, exc_tb):
        if not exc_type:
            return
        try:
            raise exc_val
        except self.ignored as exc:
            # do nothing on these ignored errors
            # we cannot log them either as the exception might contain the entire SQL expression
            return
        except sql_exc.SQLAlchemyError as exc:
            msg = str(exc)
            self.critical(msg)
            raise RepositoryDbError(msg) from exc

    def __gen_wrapper(self, f, *args, **kwargs):
        with self:
            for res in f(*args, **kwargs):
                yield res

    def __call__(self, f):
        @functools.wraps(f)
        def wrapper(slf, *args, **kw):
            self.listener = slf.listener
            with self:
                if inspect.isgeneratorfunction(f):
                    return self.__gen_wrapper(f, slf, *args, **kw)
                else:
                    return f(slf, *args, **kw)
        return wrapper


class ORMSessionAware:
    def __init__(self, session: orm.Session, commit_enabled: bool = True, **kwargs):
        self._session = session
        self.commit_enabled = commit_enabled

    @property
    def session(self):
        return self._session

    def save_commit(self):
        if self.commit_enabled:
            self._session.commit()
        else:
            self._session.flush()


class RepoDbMapper:
    def __init__(
        self,
        library: LibraryStatus,
        repo_root: str = None,
        user: str = UNKNOWN_USER,
        timezone: tzinfo = timezone.utc,
        **kwargs
    ):
        self.library = library
        self.repo_root = repo_root
        self.user = user
        self.timezone = timezone
        self.reset_now()

    @property
    def now(self):
        self._now = self._now or datetime.now(tz=self.timezone)
        return self._now

    def reset_now(self):
        self._now = None

    def _create_res_ref(
        self,
        db_path: db.RepoPath,
        path: str = None, name: str = None, parent_path: str = None, library: str = None
    ) -> api.RepoResourceRef:
        return api.RepoResourceRef(
            name=name or path or db_path.name,
            parent_path=parent_path or (db_path.parent_path if db_path else None) or '',
            repo_root=self.repo_root,
            library=library
        )

    def _create_obj_ref(self, object_uuid):
        return api.RepoObjectRef(uuid=object_uuid, repo_root=self.repo_root, library=self.library.id)

    def _new_db_path(self, res: api.RepoResource, as_import=False) -> db.RepoPath:
        res_ref = api.as_resource_ref(res, self.repo_root)
        return db.RepoPath(
            path=res_ref.path,
            name=res_ref.name,
            parent_path=None if res_ref.is_root else res_ref.parent_path,
            object_uuid=res.object.uuid if res.object else None,
            meta=res.meta,
            timestamp_created=res.attrs.get('created', self.now) if as_import else self.now,
            user_created=res.attrs.get('created_by', self.user) if as_import else self.user,
            timestamp_modified=res.attrs.get('modified', self.now) if as_import else self.now,
            user_modified=res.attrs.get('modified_by', self.user) if as_import else self.user,
        )  # type: ignore

    def _update_path(self, source: db.RepoPath, target: db.RepoPath, as_import=False):
        """copy non-identifying state from source to target path"""
        target.meta = source.meta
        target.object_uuid = source.object_uuid
        self._update_audit_attributes(source, target, as_import)

    def _update_object(self, source: db.RepoObject, target: db.RepoObject, as_import=False):
        """copy non-identifying state from source to target object"""
        target.data_json = source.data_json
        target.kind_path = source.kind_path
        target.meta = source.meta
        target.immutable = source.immutable
        self._update_audit_attributes(source, target, as_import)

    def _update_audit_attributes(self, source: db.AuditMixin, target: db.AuditMixin, as_import=False):
        if as_import:
            target.user_created = source.user_created or self.user
            target.timestamp_created = source.timestamp_created or datetime.now(tz=self.timezone)
            target.user_modified = source.user_modified or self.user
            target.timestamp_modified = source.timestamp_modified or datetime.now(tz=self.timezone)
        else:
            target.user_modified = self.user
            target.timestamp_modified = datetime.now(tz=self.timezone)

    def _new_db_obj(self, obj: api.RepoObject = None, as_import=False) -> db.RepoObject:
        return db.RepoObject(
            data_json=obj.data if obj else None,
            kind_path=obj.attrs.get('kind', None) if obj else None,
            meta=obj.meta if obj else {},
            immutable=obj.attrs.get('immutable', False) if obj else False,
            timestamp_created=obj.attrs.get('created', self.now) if (obj and as_import) else self.now,
            user_created=obj.attrs.get('created_by', self.user) if (obj and as_import) else self.user,
            timestamp_modified=obj.attrs.get('modified', self.now) if (obj and as_import) else self.now,
            user_modified=obj.attrs.get('modified_by', self.user) if (obj and as_import) else self.user,
        )

    def map_object(self, db_obj: db.RepoObject) -> api.RepoObject:
        return api.RepoObject(
            id_ref=self._create_obj_ref(db_obj.uuid),
            data=db_obj.data_json,
            meta=cast(api_json.JsonDict, db_obj.meta),
            attrs=AttrDict(
                kind=api.RepoResourceRef(db_obj.kind_path) if db_obj.kind_path else None,
                immutable=db_obj.immutable,
                created=db_obj.timestamp_created,
                created_by=db_obj.user_created,
                modified=db_obj.timestamp_modified,
                modified_by=db_obj.user_modified
            )
        )

    def map_resource(self, db_path: db.RepoPath, library: str = None, include_object=True):
        if include_object:
            object = self.map_object(db_path.object) if db_path.object else None
        else:
            object = self._create_obj_ref(db_path.object_uuid) if db_path.object_uuid else None
        return api.RepoResource(
            id_ref=self._create_res_ref(db_path, library),
            object=object,
            meta=cast(api_json.JsonDict, db_path.meta),
            attrs=AttrDict(
                created=db_path.timestamp_created,
                created_by=db_path.user_created,
                modified=db_path.timestamp_modified,
                modified_by=db_path.user_modified
            )
        )


class QDSLParserFactory:
    """Mixin for the DbRepository, providing query DSL parser lookup"""
    user: str = UNKNOWN_USER

    ACCOUNTS_USER_PREFIX = 'users/'
    ACCOUNTS_APPLICATION_PREFIX = 'applications/'

    def __init__(self):
        self._default_parser_class = api_qdsl.QueryDSL2PredicateParser
        self._parser_class_by_kind: Dict[str, Type[api_qdsl.QueryDSL2PredicateParser]] = {}

        # TODO: should be setup externally ...
        import tsa.repo.api.kinds.tsa_query as kind_tsa_query
        self.register_qdsl_parser_class(kind_tsa_query.KIND, kind_tsa_query.QueryDSL2PredicateParser)

    def register_qdsl_parser_class(self, kind: api.RefLike, qdsl_parser_class: Type[api_qdsl.QueryDSL2PredicateParser]):
        kind_path = api_std.as_kind_ref(kind).path
        self._parser_class_by_kind[kind_path] = qdsl_parser_class

    def register_default_qdsl_parser_class(self, qdsl_parser_class: Type[api_qdsl.QueryDSL2PredicateParser]):
        self._default_parser_class = qdsl_parser_class

    def lookup_user_id(self, user_identifier: str) -> Optional[str]:
        if user_identifier.startswith(self.ACCOUNTS_USER_PREFIX) or \
                user_identifier.startswith(self.ACCOUNTS_APPLICATION_PREFIX):
            return user_identifier
        try:
            return f"{self.ACCOUNTS_USER_PREFIX}{uuid.UUID(user_identifier)}"
        except ValueError:
            pass
        # TODO: lookup user in the accounts database (by email or by name)
        # return None when not found
        return None

    @abstractproperty
    def now(self):
        ...

    def create_qdsl_parser(self, kinds: List[api.RefLike]):
        qdsl_parser_class = self._default_parser_class
        # for now only support single kind
        if kinds:
            kind_path = api_std.as_kind_ref(kinds[0]).path
            qdsl_parser_class = self._parser_class_by_kind.get(kind_path, api_qdsl.QueryDSL2PredicateParser)

        return qdsl_parser_class(
            current_user=self.user,
            username_callback=lambda usr: self.lookup_user_id(usr),
            now_callback=lambda: self.now
        )

    def parse_qdsl_to_predicate(self, kinds: List[api.RefLike], query: str):
        return self.create_qdsl_parser(kinds).parse_predicate(query)


class DbRepository(api.Repository, ListenerSource, ORMSessionAware, RepoDbMapper, QDSLParserFactory):

    def __init__(
        self,
        session: orm.Session,
        library: LibraryStatus,
        user: str = UNKNOWN_USER,
        timezone: tzinfo = timezone.utc,
        listener: api.ResultListener = NOOP_LISTENER,
        repo_root='',
        commit_enabled=True,
        **kwargs
    ):
        ORMSessionAware.__init__(self, session, commit_enabled=commit_enabled, **kwargs)
        RepoDbMapper.__init__(self, user=user, timezone=timezone, library=library, repo_root=repo_root, **kwargs)
        ListenerSource.__init__(self, listener, **kwargs)
        QDSLParserFactory.__init__(self)

    def save_commit(self):
        super().save_commit()
        self.reset_now()

    @wrap_sql_exceptions()
    def post_object(self, obj: api.RepoObject, as_import=False) -> api.RepoObject:
        db_obj = self._new_db_obj(obj, as_import)
        self.session.add(db_obj)
        self.save_commit()
        self.set_response_status(HTTPStatus.CREATED)
        return self.map_object(db_obj)

    @wrap_sql_exceptions()
    def get_object(self, ref: api.RefLike) -> Optional[api.RepoObject]:
        """Get the metadata of a repository object"""
        obj_ref = api.as_object_ref(ref, self.repo_root, self.library.id)
        try:
            db_obj = self.session.query(db.RepoObject).filter(db.RepoObject.uuid == obj_ref.uuid).one()
        except orm_exc.NoResultFound:
            self.error('Not Found: %s', obj_ref)
            self.set_response_status(HTTPStatus.NOT_FOUND)
            return None
        self.set_response_status(HTTPStatus.OK)
        return self.map_object(db_obj)

    @wrap_sql_exceptions()
    def delete_object(self, ref: api.RefLike) -> api.LinkCollection:
        obj_ref = api.as_object_ref(ref, self.repo_root, self.library.id)
        db_obj = self.session.query(db.RepoObject).filter(db.RepoObject.uuid == obj_ref.uuid).one()
        self.session.delete(db_obj)
        self.save_commit()
        self.set_response_status(HTTPStatus.OK)
        return api.LinkCollection().with_link(RELATIONS.SELF, self._create_obj_ref(db_obj.uuid))

    @wrap_sql_exceptions()
    def put_object(self, obj: api.RepoObject, as_import=False) -> Optional[api.RepoObject]:
        obj_ref = api.as_object_ref(obj, self.repo_root, self.library.id)
        current_db_obj = self.session.query(db.RepoObject).filter(db.RepoObject.uuid == obj_ref.uuid).one_or_none()
        if current_db_obj:
            if current_db_obj.immutable:
                self.set_response_status(HTTPStatus.CONFLICT)
                self.error(f"Cannot change immutable object: '{obj_ref}'")
                return self.map_object(current_db_obj)
            db_obj = self._new_db_obj(obj, as_import)
            self._update_object(db_obj, current_db_obj, as_import)
            self.save_commit()
            self.set_response_status(HTTPStatus.OK)
            return self.map_object(current_db_obj)
        else:
            self.set_response_status(HTTPStatus.NOT_FOUND)
            return None

    @wrap_sql_exceptions()
    def put_resource(self, res: api.RepoResource, cascade_object=True, as_import=False) -> api.RepoResource:
        library = res.id_ref.library
        if library and library != self.library.id:
            self.error(
                f'Not Implemented: resource {res} that does not reside in default library {self.library.id}'
            )
            self.set_response_status(HTTPStatus.NOT_IMPLEMENTED)
        # recurse to create parent paths if needed
        if not res.id_ref.is_root:
            with self.silenced_listener():
                parent_ref = res.id_ref.parent
                if parent_ref and self.get_resource(parent_ref) is None:
                    self.put_resource(api.RepoResource(id_ref=parent_ref))
        new_db_path = self._new_db_path(res, as_import)
        # try query existing resource
        current_db_path = self.session.query(db.RepoPath).filter(db.RepoPath.path == new_db_path.path).one_or_none()
        current_obj_uuid = current_db_path.object_uuid if current_db_path else None
        if current_db_path:
            self._update_path(new_db_path, current_db_path, as_import)
            current_db_obj = current_db_path.object
            resp_status = HTTPStatus.OK
            db_path = current_db_path
        else:
            self.session.add(new_db_path)
            self.session.flush()
            resp_status = HTTPStatus.CREATED
            db_path = new_db_path

        if isinstance(res.object, api.RepoObject):
            # if an object is specified in the resource, either:
            # * update (if object existed, was not immutable, has same uuid or no uuid was specified)
            # * or create a new object (and delete the old if no other references exist)
            new_db_obj = self._new_db_obj(res.object, as_import)
            current_db_obj = db_path.object
            use_current_obj = current_db_obj and not current_db_obj.immutable and (
                new_db_obj.uuid is None or new_db_obj.uuid == current_db_obj.uuid
            )
            if use_current_obj:
                self._update_object(new_db_obj, current_db_obj, as_import)
            else:
                db_path.object = new_db_obj
            self.session.flush()
        if current_obj_uuid and db_path.object_uuid != current_obj_uuid and cascade_object:
            self._delete_orphan_objects((current_obj_uuid,))
        self.save_commit()
        self.set_response_status(resp_status)
        return self.map_resource(db_path, library=library, include_object=True)

    @wrap_sql_exceptions()
    def get_resource(self, ref: api.RefLike, include_object=True) -> Optional[api.RepoResource]:
        """Get the metadata of a repository resource"""
        res_ref = api.as_resource_ref(ref, self.repo_root)
        try:
            db_path = self.session.query(db.RepoPath).filter(db.RepoPath.path == res_ref.path).one()
        except orm_exc.NoResultFound:
            self.error('Not Found: %s', res_ref)
            self.set_response_status(HTTPStatus.NOT_FOUND)
            return None
        self.set_response_status(HTTPStatus.OK)
        return self.map_resource(db_path, res_ref.library, include_object=include_object)

    def _append_filtering_to_query(
            self,
            db_query: orm.Query,
            parent: api.RefLike = None,
            kinds: List[api.RefLike] = None,
            query: str = None,
            filter: api_pred.RepoPredicate = None,
    ):
        if parent is not None:
            parent_ref = api.as_resource_ref(parent)
            ref_pred = api_pred.RepoResource(
                path=api_pred.Path(
                    parent_path=api_pred.String(eq=parent_ref.path)
                )
            )
            db_query = db_query.filter(db_pred.create_filter(ref_pred))
        if query is not None:
            query_pred = self.parse_qdsl_to_predicate(kinds or [], query)
            db_query = db_query.filter(db_pred.create_filter(query_pred))
        if filter is not None:
            db_query = db_query.filter(db_pred.create_filter(filter))

        return db_query

    @wrap_sql_exceptions()
    def iter_resource(
        self,
        parent: api.RefLike = None,
        kinds: List[api.RefLike] = None,
        query: str = None,
        filter: api_pred.RepoPredicate = None,
        limit: int = DEFAULT_LIMIT,
        offset: int = 0
    ) -> Iterator[api.RepoResource]:
        if limit == 0:
            self.set_response_status(HTTPStatus.OK)
            return
        db_query = self.session.query(db.RepoPath).select_from(db.RepoPath).outerjoin(
            db.RepoObject, db.RepoPath.object_uuid == db.RepoObject.uuid
        )
        db_query = self._append_filtering_to_query(
            db_query,
            parent,
            kinds,
            query,
            filter,
        )
        db_query = db_query.order_by(db.RepoPath.path)
        db_query = db_query.offset(offset).limit(limit)
        for db_path in db_query:
            yield self.map_resource(
                db_path,
                api.as_resource_ref(parent).library if parent else None,
                include_object=False
            )
        self.set_response_status(HTTPStatus.OK)

    @wrap_sql_exceptions()
    def count_resources(
            self,
            parent: api.RefLike,
            kinds: Optional[List[api.RefLike]] = None,
            query: str = None,
            filter: api_pred.RepoPredicate = None,
    ) -> int:
        db_query = self.session.query(func.count(db.RepoPath.path)).select_from(db.RepoPath).outerjoin(
            db.RepoObject, db.RepoPath.object_uuid == db.RepoObject.uuid
        )
        db_query = self._append_filtering_to_query(
            db_query,
            parent,
            kinds,
            query,
            filter,
        )
        count = db_query.scalar()
        self.set_response_status(HTTPStatus.OK)
        return count

    @wrap_sql_exceptions()
    def delete_resource(
        self, ref: api.RefLike, cascade_children: bool = False, cascade_object: bool = True
    ) -> Optional[api.LinkCollection]:
        res_ref = api.as_resource_ref(ref, self.repo_root)
        path_prefix_pattern = res_ref.path + '%' if res_ref.is_parent else res_ref.path
        count_path_deletions = self.session.execute(
            'SELECT count(*) FROM path WHERE path LIKE :path_prefix',
            {'path_prefix': path_prefix_pattern}
        ).scalar()
        if count_path_deletions == 0:
            self.error('Not Found: %s', res_ref)
            self.set_response_status(HTTPStatus.NOT_FOUND)
            return None
        if count_path_deletions > 1:
            if not cascade_children:
                self.error("Cannot delete '%s': child paths present, and 'cascade_children' not enabled.", res_ref)
                self.set_response_status(HTTPStatus.CONFLICT)
                return None
            else:
                self.info(f"Cascade-deleting {count_path_deletions} descendant paths.")
        if cascade_object:
            obj_delete_count, obj_no_delete_count = self._count_obj_deletions_for_path_like(path_prefix_pattern)
            if obj_no_delete_count > 0:
                self.warning(f"Not cascade-deleting {obj_no_delete_count} objects with other references.")
            if obj_delete_count > 0:
                self.info(f"Deleting {obj_delete_count} object(s).")
            self.session.execute('SET CONSTRAINTS ALL DEFERRED')
            self._delete_obj_for_path_like(path_prefix_pattern)
        self.session.execute(
            "DELETE FROM path WHERE path LIKE :path_prefix",
            {'path_prefix': path_prefix_pattern}
        )
        self.save_commit()
        self.set_response_status(HTTPStatus.OK)
        return api.LinkCollection().with_link(RELATIONS.SELF, res_ref)

    @wrap_sql_exceptions()
    def get_data(self, ref: api.RefLike) -> Any:
        """Get the data of resource or object"""
        ref = api.as_data_ref(ref, self.repo_root, self.library.id)
        db_obj = self._get_data_container(ref, create_object=False)
        if db_obj is None:
            # response status already set
            return None
        self._set_data_response_attributes(ref, db_obj)
        data = db_obj.data_json
        if data is None:
            self.info(f"Reference exists but has no data: '{ref}'", action='get_data')
            self.set_response_status(HTTPStatus.NO_CONTENT)
        else:
            self.set_response_status(HTTPStatus.OK)
        return data

    @wrap_sql_exceptions()
    def put_data(self, ref: api.RefLike, data: Any) -> Optional[api.LinkCollection]:
        ref = api.as_data_ref(ref, self.repo_root, self.library.id)
        db_obj = self._get_data_container(ref, create_object=True)
        if db_obj is None:
            # response status already set
            return None
        db_obj.data_json = data
        self.save_commit()
        self.set_response_status(HTTPStatus.OK)
        links = api.LinkCollection()
        links.add_link(RELATIONS.OBJECT, self._create_obj_ref(db_obj.uuid))
        links.add_link(RELATIONS.SELF, ref)
        base_ref = ref.base_ref
        if isinstance(base_ref, api.RepoResourceRef):
            links.add_link(RELATIONS.RESOURCE, base_ref)
        return links

    def delete_data(self, ref: api.RefLike) -> api.LinkCollection:
        return self.put_data(ref, None)

    def _get_data_container(self, ref: api.Ref, create_object=False) -> Optional[db.RepoObject]:
        base_ref = ref.base_ref if ref else None
        if isinstance(base_ref, api.RepoResourceRef):
            return self._get_data_container_for_resource(ref, base_ref, create_object)
        if isinstance(base_ref, api.RepoObjectRef):
            return self._get_data_container_for_object(ref, base_ref)
        self.error('Invalid Reference: %s', ref, action='get_data')
        self.set_response_status(HTTPStatus.BAD_REQUEST)
        return None

    def _get_data_container_for_object(self, ref: api.Ref, base_ref: api.RepoObjectRef):
        db_obj = self.session.query(db.RepoObject).filter(
            db.RepoObject.uuid == base_ref.uuid
        ).one_or_none()
        if db_obj is None:
            self.error('Not found: %s', ref, action='get_data')
            self.set_response_status(HTTPStatus.NOT_FOUND)
        return db_obj

    def _get_data_container_for_resource(self, ref: api.Ref, base_ref: api.RepoResourceRef, create_object: bool):
        # TODO optimize eager joining
        db_path = self.session.query(db.RepoPath).filter(db.RepoPath.path == base_ref.path).one_or_none()
        if db_path is None:
            self.error('Not found: %s', ref, action='get_data')
            self.set_response_status(HTTPStatus.NOT_FOUND)
            return None
        if db_path.object is None:
            if create_object:
                db_path.object = self._new_db_obj()
                self.session.flush()
            else:
                self.info(f"Resource reference exists but has no object: '{ref}'", action='get_data')
                self.set_response_status(HTTPStatus.NO_CONTENT)
                return None
        return db_path.object

    def _set_data_response_attributes(self, ref, db_obj):
        if db_obj.meta:
            dataHeaders = ['Content-Type']
            for header in dataHeaders:
                if header in db_obj.meta:
                    self.set_response_attribute(header, db_obj.meta[header])
        base_ref = ref.base_ref
        if isinstance(base_ref, api.RepoResourceRef):
            self.set_response_attribute('Link', f"<{base_ref.url}>", rel='resource')
        self.set_response_attribute('Link', f"<{self._create_obj_ref(db_obj.uuid).url}>", rel='object')
        self.set_response_attribute('Link', f"<{ref.url}>", rel='self')

    def _delete_orphan_objects(self, object_uuids: Sequence[str] = None):
        from_clause = 'FROM object AS obj WHERE NOT EXISTS (SELECT object_uuid FROM path WHERE object_uuid = obj.uuid)'
        binding = {}
        if object_uuids:
            from_clause += ' AND uuid IN :object_uuids'
            binding = {'object_uuids': tuple(uuid for uuid in object_uuids)}
        ref_count = self.session.execute('SELECT COUNT(*) ' + from_clause, binding).scalar()
        if ref_count > 0:
            self.session.execute('DELETE ' + from_clause, binding)
            self.info(f"Deleted {ref_count} orphaned objects.", action='delete_orphan_objects')
        else:
            self.debug(f"No orphaned objects found.", action='delete_orphan_objects')
        return ref_count

    def _delete_obj_for_path_like(self, path_prefix_pattern):
        self.session.execute(
            """
DELETE FROM object WHERE uuid IN (
    SELECT p.object_uuid
    FROM
        (
            SELECT object_uuid , count(*) AS del_count
            FROM path
            WHERE path LIKE :path_prefix and object_uuid IS NOT NULL
            GROUP BY object_uuid
        ) AS d,
        path p
    WHERE p.object_uuid = d.object_uuid
    GROUP BY p.object_uuid, d.del_count
    HAVING count(*) = d.del_count
)
""",
            {'path_prefix': path_prefix_pattern}
        )

    def _count_obj_deletions_for_path_like(self, path_prefix_pattern) -> Tuple[int, int]:
        count_obj_deletions_result = self.session.execute(
            """
SELECT o.del_case, count(*)
FROM
(
    SELECT
        p.object_uuid,
        d.del_count AS del_count,
        count(*) AS ref_count,
        CASE WHEN d.del_count < count(*) THEN 'NO_DELETE' ELSE 'DELETE' END as del_case
    FROM
        (
            SELECT object_uuid, count(*) AS del_count
            FROM path
            WHERE path LIKE :path_prefix and object_uuid IS NOT NULL
            GROUP BY object_uuid
        ) AS d,
        path p
    WHERE p.object_uuid = d.object_uuid
    GROUP BY p.object_uuid, d.del_count
    HAVING count(*) >= d.del_count
) AS o
GROUP BY o.del_case
""",
            {'path_prefix': path_prefix_pattern}
        )
        count_obj_deletions = {case: count for (case, count, ) in count_obj_deletions_result}
        return count_obj_deletions.get('DELETE', 0), count_obj_deletions.get('NO_DELETE', 0)
