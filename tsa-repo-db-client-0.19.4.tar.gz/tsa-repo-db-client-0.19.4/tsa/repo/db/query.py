"""utility functions to map the predicate api to sqlalchemy ORM query filters"""

from typing import Any, Iterable, Iterator
from uuid import uuid4
from sqlalchemy import (
    and_, or_, not_, text, bindparam, DATETIME
)
import itertools
from sqlalchemy.dialects.postgresql import JSONB
import sqlalchemy.orm as orm

import tsa.repo.api.predicate as pred
from tsa.repo.api.message import (
    RepositoryError
)
from . import model as db

QueryCriterion = Any


def _combine_filters(combiner, filters: Iterable[QueryCriterion]) -> QueryCriterion:
    filter_iterator = iter(filters)
    first_filter = next(filter_iterator, None)
    if first_filter is None:
        return None
    second_filter = next(filter_iterator, None)
    if second_filter is None:
        return first_filter
    return combiner(first_filter, second_filter, *list(filter_iterator))


def _union_filters(filters: Iterable[QueryCriterion]) -> QueryCriterion:
    return _combine_filters(or_, filters)


def _intersect_filters(filters: Iterable[QueryCriterion]) -> QueryCriterion:
    return _combine_filters(and_, filters)


def create_filter(filter: pred.RepoPredicate) -> QueryCriterion:
    return _intersect_filters(_iter_filter(filter))


def _iter_filter(filter: pred.RepoPredicate) -> Iterator[QueryCriterion]:
    if isinstance(filter, pred.TrueFalsePredicate):
        if not filter.value:
            yield text('false')
        return
    if isinstance(filter, pred.And):
        for f in filter._and:
            yield from _iter_filter(f)
        return
    if isinstance(filter, pred.Or):
        yield _union_filters(create_filter(f) for f in filter._or)
        return
    if isinstance(filter, pred.Not):
        yield not_(create_filter(filter._not))
        return
    if isinstance(filter, pred.RepoResource):
        if filter.meta:
            yield create_jsonb_filter(db.RepoPath.meta, filter.meta)
        if filter.audit:
            yield create_audit_filter(db.RepoPath, filter.audit)
        if filter.path:
            yield create_path_filter(filter.path)
        return
    if isinstance(filter, pred.RepoObject):
        if filter.data:
            yield create_jsonb_filter(db.RepoObject.data_json, filter.data)
        if filter.meta:
            yield create_jsonb_filter(db.RepoObject.meta, filter.meta)
        if filter.audit:
            yield create_audit_filter(db.RepoObject, filter.audit)
        return
    if filter is not None:
        raise RepositoryError(f"Unsupported resource filter expression: '{filter}'")


def create_audit_filter(table, filter: pred.AuditPredicate) -> QueryCriterion:
    return _intersect_filters(_iter_audit_filter(table, filter))


def _iter_audit_filter(table, filter: pred.AuditPredicate) -> Iterator[QueryCriterion]:
    if isinstance(filter, pred.TrueFalsePredicate):
        if not filter.value:
            yield text('false')
        return
    if isinstance(filter, pred.And):
        for f in filter._and:
            yield from _iter_audit_filter(table, f)
        return
    if isinstance(filter, pred.Or):
        yield _union_filters(create_audit_filter(table, f) for f in filter._or)
        return
    if isinstance(filter, pred.Not):
        yield not_(create_audit_filter(table, filter._not))
        return
    if isinstance(filter, pred.Audit):
        if filter.timestamp_created:
            yield create_timestamp_filter(table.timestamp_created, filter.timestamp_created)
        if filter.timestamp_modified:
            yield create_timestamp_filter(table.timestamp_modified, filter.timestamp_modified)
        if filter.user_created:
            yield create_string_filter(table.user_created, filter.user_created)
        if filter.user_modified:
            yield create_string_filter(table.user_modified, filter.user_modified)
        return
    if filter is not None:
        raise RepositoryError(f"Unsupported audit filter expression: '{filter}'")


def create_timestamp_filter(field, filter: pred.DatetimePredicate) -> QueryCriterion:
    return _intersect_filters(_iter_timestamp_filter(field, filter))


def _iter_timestamp_filter(field, filter: pred.DatetimePredicate) -> Iterator[QueryCriterion]:
    if isinstance(filter, pred.TrueFalsePredicate):
        if not filter.value:
            yield text('false')
        return
    if isinstance(filter, pred.And):
        for f in filter._and:
            yield from _iter_timestamp_filter(field, f)
        return
    if isinstance(filter, pred.Or):
        yield _union_filters(create_timestamp_filter(field, f) for f in filter._or)
        return
    if isinstance(filter, pred.Not):
        yield not_(create_timestamp_filter(field, filter._not))
        return
    if isinstance(filter, pred.Datetime):
        before = filter.before
        after = filter.after
        if after and before:
            yield field.between(after, before)
        elif after:
            yield field >= after
        elif before:
            yield field <= before
        if filter.same_date:
            yield text(
                f"date_trunc('day',{field.table.name}.{field.name}) = date_trunc('day', :ts )"
            ).bindparams(
                bindparam('ts', value=filter.same_date, type_=DATETIME, unique=False)
            )
        if filter.same_time:
            yield text(
                f"date_trunc('second',{field.table.name}.{field.name}) = date_trunc('second',:ts)"
            ).bindparams(
                bindparam('ts', value=filter.same_time, type_=DATETIME, unique=True)
            )
        return
    if filter is not None:
        raise RepositoryError(f"Unsupported timestamp filter expression: '{filter}'")


def create_path_filter(filter: pred.PathPredicate):
    return _intersect_filters(_iter_path_filter(filter))


def _iter_path_filter(filter: pred.PathPredicate):
    if isinstance(filter, pred.TrueFalsePredicate):
        if not filter.value:
            yield text('false')
        return
    if isinstance(filter, pred.And):
        for f in filter._and:
            yield from _iter_path_filter(f)
        return
    if isinstance(filter, pred.Or):
        yield _union_filters(create_path_filter(f) for f in filter._or)
        return
    if isinstance(filter, pred.Not):
        yield not_(create_path_filter(filter._not))
        return
    if isinstance(filter, pred.Path):
        if filter.name:
            yield create_string_filter(db.RepoPath.name, filter.name)
        if filter.path:
            yield create_string_filter(db.RepoPath.path, filter.path)
        if filter.parent_path:
            yield create_string_filter(db.RepoPath.parent_path, filter.parent_path)
        return
    if filter is not None:
        raise RepositoryError(f"Unsupported path filter expression: '{filter}'")


def create_string_filter(field, filter: pred.StringPredicate) -> QueryCriterion:
    return _intersect_filters(_iter_string_filter(field, filter))


def _iter_string_filter(field, filter: pred.StringPredicate) -> Iterator[QueryCriterion]:
    if isinstance(filter, pred.TrueFalsePredicate):
        if not filter.value:
            yield text('false')
        return
    if isinstance(filter, pred.And):
        for f in filter._and:
            yield from _iter_string_filter(field, f)
        return
    if isinstance(filter, pred.Or):
        yield _union_filters(create_string_filter(field, f) for f in filter._or)
        return
    if isinstance(filter, pred.Not):
        yield not_(create_string_filter(field, filter._not))
        return
    if isinstance(filter, pred.String):
        if filter.eq:
            yield field == filter.eq
        if filter.like:
            yield field.like(filter.like)
        return
    if isinstance(filter, pred.Contains):
        if isinstance(filter.contains, str):
            yield field.like(f'%{filter.contains}%')
        else:
            raise RepositoryError(
                f"Unsupported contains argument for string field: '{filter.contains}. "
                + 'Please escape as a json string to disambiguate'
            )
        return
    if filter is not None:
        raise RepositoryError(f"Unsupported string filter expression: '{filter}'")


def create_jsonb_filter(field, filter: pred.Predicate, at=None) -> QueryCriterion:
    if isinstance(filter, pred.TrueFalsePredicate):
        if not filter.value:
            return text('false')
    if isinstance(filter, pred.And):
        return _intersect_filters(create_jsonb_filter(field, f, at) for f in filter._and)
    if isinstance(filter, pred.Or):
        return _union_filters(create_jsonb_filter(field, f, at) for f in filter._or)
    if isinstance(filter, pred.Not):
        return not_(create_jsonb_filter(field, filter._not, at))
    if isinstance(filter, pred.Contains):
        contains_arg = filter.contains
        if at is not None:
            return text(
                f"{field.table.name}.{field.name}{_path_to_access_operator(at)} @> :json"
            ).bindparams(
                bindparam('json', value=contains_arg, type_=JSONB, unique=True)
            )
        return field.comparator.contains(contains_arg)
    if isinstance(filter, pred.At):
        new_at = filter.at if at is None else f'{at}.{filter.at}'
        if filter.exists:
            return create_jsonb_filter(field, filter.exists, new_at)
        return text(
            f"{field.table.name}.{field.name} @? :filter_at "
        ).bindparams(
            bindparam('filter_at', value=f'{at}.{filter.at}', unique=True)
        )
    if isinstance(filter, pred.String):
        str_filters = [f'${at}']
        if filter.eq:
            str_filters.append(f'( @ == "{filter.eq}" )')
        if filter.like:
            like_regexp = filter.like
            for c in '[\\^$.|?*+()':
                like_regexp = like_regexp.replace(c, '\\'+c)
            like_regexp = like_regexp.replace('%', '.*').replace('_', '.')
            str_filters.append(f'( @ like_regex "^{like_regexp}$" )')
        json_filter = ' ? '.join(str_filters)
        return text(
            f"{field.table.name}.{field.name} @? :json_filter"
        ).bindparams(
             bindparam('json_filter', value=json_filter, unique=True)
        )
    raise RepositoryError(f"Unsupported jsonb filter expression: '{filter}'")


def _path_to_access_operator(at):
    # Convert a jsonpath (https://www.postgresql.org/docs/12/functions-json.html#FUNCTIONS-SQLJSON-PATH)
    # to a https://www.postgresql.org/docs/12/functions-json.html#FUNCTIONS-JSON-PROCESSING navigation operator,
    # (As I wasn't able to apply the contains operator to a path selected by a jsonpath expression)
    if '*' in at:
        raise RepositoryError(f"Unsupported path '{at}' for contains expression.")
    return ''.join(
        f"->{part[:-1]}" if part[-1] == ']' else f"->'{part}'"
        for dot_part in at.split('.') if dot_part
        for part in dot_part.split('[')
    )
