from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime
from sqlalchemy.orm import relationship
import sqlalchemy.dialects.postgresql as postgresql
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.types import TypeEngine
from typing import TYPE_CHECKING
import datetime
import uuid


Base = declarative_base()
if TYPE_CHECKING:
    PostgreSQLUUID = TypeEngine[uuid.UUID]
else:
    PostgreSQLUUID = postgresql.UUID(as_uuid=True)


class AuditMixin:
    user_created = Column(String)
    timestamp_created = Column(DateTime)
    user_modified = Column(String)
    timestamp_modified = Column(DateTime)


class RepoObject(Base, AuditMixin):
    __tablename__ = 'object'
    uuid = Column(PostgreSQLUUID, primary_key=True, default=uuid.uuid4, unique=True, nullable=False)
    data_json = Column(postgresql.JSONB)
    kind_path = Column(String, ForeignKey('path.path'))
    meta = Column(postgresql.JSONB)
    immutable = Column(Boolean, default=False)

    kind = relationship('RepoPath', primaryjoin='RepoObject.kind_path == RepoPath.path')


class RepoPath(Base, AuditMixin):
    __tablename__ = 'path'
    path = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    parent_path = Column(String, ForeignKey('path.path'))
    meta = Column(postgresql.JSONB)
    object_uuid = Column(PostgreSQLUUID, ForeignKey('object.uuid'))  # type: ignore

    object = relationship("RepoObject", primaryjoin="RepoPath.object_uuid == RepoObject.uuid")
    parent = relationship("RepoPath",  primaryjoin='RepoPath.path == RepoPath.parent_path')
    # children = relationship("RepoPath", backref="parent")
