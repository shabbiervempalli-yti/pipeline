import sys
from tsa.repo.api.kinds.tsa_query import QueryDSL2PredicateParser
from tsa.repo.api.message import RepositoryError
from tsa.repo.db.query import create_filter

query = ' '.join(sys.argv[1:])
parser = QueryDSL2PredicateParser('test_user')
# Console Markup sequences
CEND = '\33[0m'
CBOLD = '\33[1m'
CRED = '\33[31m'


def show(title, content):
    print(CBOLD + title + CEND)
    print(content)
    print()


try:
    show('INPUT', query)
    terms = parser.parse_terms(query)
    show('PARSED TERMS', terms)
    filter = create_filter(terms.as_predicate(parser))
    show('SQL CLAUSE', filter)
    show(
        'SQL BIND ARGUMENTS',
        "\n".join(f'{k}\t: {v}' for k, v in filter.compile().params.items())
    )
except RepositoryError as e:
    show('ERROR', CRED + str(e) + CEND)
