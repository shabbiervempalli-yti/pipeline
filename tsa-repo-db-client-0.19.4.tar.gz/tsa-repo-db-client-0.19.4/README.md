# Repository Postgresql Implementation

## MVP

### Features
* [x] CRD of objects and resources
  * [x] POST, GET, DELETE object
  * [x] PUT, GET, DELETE resource (with or without object)
  * [x] GET data
* [x] Delete cascading for resources
  * [x] to owned (orphaned) objects
  * [x] to child resources
* [x] updates
  * [x] PUT resource on existing resource
  * [x] PUT object
  * [x] PUT, DELETE data on object and resource base
* [ ] Listing/embeddings:
  * [ ] GET resource : include/exclude object/data/children
  * [ ] link or embedding
  * [X] simple filters on name, title, (kind), audit attributes
* [ ] kinds
  * [ ] store kinds on resources and objects (motivation: resource can later point into an object for its data, resulting in an other kind)
  * [ ] filter on kind in listing


### Design decisions
* review comments #450
  * [ ] limit visibility of objects (by default) on resource api (e.g. no embedding)
  * [ ] (log/error) message representations:
      * [x] message codes with fixed message template so that i18n is possible 
            server or client side 
            DECISION: remove this feature for now
  * [x] naming of root path for objects currently ('/obj/<library>')
            DECISION: rename to '/object/'
  * [x] naming: base_path vs repo_root
            DECISION: keep 'repo_root'
  * [x] naming: Command classes (e.g. DeleteLibraryCommand i.o. DeleteLibrary )
            DECISION: keep it
  * [ ] error handling non-app Exception (TypeError, AttributeError and others)
            TODO
  * [ ] (perceived?) uglyness of the main Flask route implementation
            TODO: research Method View

### Development
* [x] fully type safe
* [x] dependencies in setup.cfg, requirements.txt is freeze only
* [ ] replace tsa.repo.api.JsonOptions with a correct design (related to embedding/linking)
* [ ] improve test coverage
* [ ] improve logging (e.g. alembic executions), fatal error handling, stackdriver/sentry logging
* review comments #450
  * [ ] add documentation
     * [ ] api.links.Link : DECISION: TODO in link/embedding implementation
  * [x] improve legibility (whitespace)
      DECISION: I'll do my best (promised!)
  * [x] agree on usage of relative package naming within modules
      DECISION: ok relative but with  python/extern/intern/self module split
  * [x] abbreviations?
      OK, aandachtspunt ...
  * [ ] a general design documentation
  * [ ] api.message.listenerstack : can be a @contextmanager
  * [x] __repr__ vs __str__ in error messages (quoting)
      DECISION: only use string representation (keep standard @dataclass representation)
  * [x] see wether RepoResourceBase.parse() can be less epic (but it is a nice story ...)
      OK: whitespace and comments help ...
  * [ ] type annotations/ circular dependency on Settings in tsa.repo.db_admin.init_db.command
      TODO: remove entaglement between settings and commands 
  * [x] better __eq__ for tsa.repo.api.refs
      DECISION: require second argument to be instance of Ref
  * [x] use HTTPStatus instead of own constans for status codes
  * [x] do not use docstring under class attributes
* [ ] use tabulate in the cli
* review comments #466
  * [ ] replace NoEmptyOrderedDict with good query DSL parser/serializer
  * [ ] (query AST -> ORM query) transformer: (perceived?) uglyness of if statements ...
* resource query implementation
  * [x] query AST
  * [x] full transformation  (query AST -> ORM query)
  * [-] bi-directional transformation  (query AST -> query DSL) (update: not needed?)
  * [ ] rest binding: include query in response (and self link?)
* review #491
  * [ ] split up the parser infrastructure ( base classes like Term and Matcher, Semantics, PredicateParser) 
       from the logic implementation ( Terms and Matchers that implement keywords in the DSL) 
  * [ ] functools.reduce-ify the  _combine_filters function in query.py ?
  * [ ] fully document tsa.repo.api.api
  
### Deployment
* server (python)
   * [x] standalone
   * [x] with tsa on local db
   * [ ] with tsa on remote (staging) db (or over http client)
* docker 
   * [x] standalone
   * [x] with tsa
* drone
   * [x] build and test
   * [x] standalone image
   * [x] tsa combined image

### Usage by TSA


#### new configs
```
[POST|GET] /config/model => /repo/tsa/model/
[GET|DELETE|PUT|PATCH]  /config/model/<model_config_name> => /repo/tsa/model/<model_config_name>
[POST|GET] /config/query => /repo/tsa/query/
[GET|DELETE|PUT|PATCH]  /config/query/<query_config_name> => /repo/tsa/query/<query_config_name>
[POST|GET] /config/<kind> => /repo/tsa/<kind>/
[GET|DELETE|PUT|PATCH]  /config/<kind>/<kind_config_name> => /repo/tsa/<kind>/<kind_config_name>
```
Decided: use metadata wrapper as payload:
```
{
  "name": "MyQuery", # path name, only for POST or if consistent with path
  "kind": "query", #implicit from /config/query endpoint
  "meta" : {
    "title" : "My Beautifull Query",
    "description": "A query specification that illustrates ..."
  },
  "data" : {
    "window": "P7D",
    "freq": "PT1H",
    "data": [ {
      "resource" : "151DF",
      "metric" : "temperature",
      "aggregation" : "mean"
    } ]
  }
}
```
(optionaly with deep paths)

##### NOTE: prio for data-endpoint:
```
[POST] /config/query => /repo/tsa/query/
[GET|DELETE|PUT]  /config/query/<query_config_name> => /repo/
[GET] /data/query/<query_config_name>
```

#### mapping of *use case* endpoints on new configs
```
[POST|GET] /estimate/model/<model_config_name> => estimates for model-by-name
[POST] /estimate => unchanged
legacy:
[POST|GET] /estimate/<resource>/<model_config_name>
[POST] /estimate/<resource>

idem for (predict|anomaly|fit|time_to_target|label|validate|anomaly_score|data|data_profile)
[POST|GET] /<use-case>/model/<model_config_name> => estimates for model-by-name

... and for other config items:
[POST|GET] /data/query/<query_config_name>

... genericly: 
[POST|GET] /<use-case>/<config-entity-name>/<query_config_name>
```
####  legacy configs (optional, by resource)

This is an optional compatiblity mapping, in case we want migration of legacy 
templates to be done in the backed
```
[POST|GET] /config/<resource>[/] 
  => /repo/tsa/model/by_resource/<resource>/
[GET|DELETE|PUT|PATCH] /config/<resource>/<config_name>
  => /repo/tsa/model/by_resource/<resource>/<config_name>
```
Possible phases:
  1) read/write from resource meta, store in repo as side effect
  2) read from repo, with fallback to meta. Write to repo and resource meta as side effect
  3) read from repo, with fallback to meta. Write to repo, delete resource meta as side effect
  4) read/write from repo only


* [ ] shortcuts (compatibility, optional)
```

GET /model_search  => GET /config/model_search
GET /schema/<schema_path> => GET /repo/tsa/schema/<current_api_version>/<schema_path>
GET /algorithm => includes algorithm templates stored in /repo/tsa/algorithm/
```

## Optional for MVP
### Features
* [ ] POST resource on parent resource (using name in representation)
* [ ] rename (move) of resources
* [ ] http client: this will make development deployment more easy (being able to use the config storage
      as deployed on staging)
* [ ] title and description for resources (helps keeping restrictions on the path)

### TSA Usage
* [ ] algorithm configs (listing in algorithm)
* [ ] schemas by API version updated on each released minor version

## Later
### Features
* [ ] GET query on objects
* [ ] patches
  * [ ] PATCH on (object/resource) metadata with merge
  * [ ] PATCH on data with json-patch (content-type)
* [ ] paging
* [ ] object and resource links
