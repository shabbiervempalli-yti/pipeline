
from setuptools import setup, find_namespace_packages
import versioneer

setup(
    name='tsa-repo-db-client',
    version=versioneer.get_version(),
    cmdclass=versioneer.get_cmdclass(),
    description='Time series analytics repository database client',
    url='https://github.com/waylayio/TS_Analytics.git',
    author='Sander Vanhove, Sam Persoon, Thomas De Smedt',
    author_email='sander.vanhove@waylay.io, sam.persoon@waylay.io, thomas@waylay.io',
    packages=find_namespace_packages(include=['tsa.repo.*']),
    package_data={"tsa.repo.db": ["py.typed"]},
    include_package_data=True,
    install_requires=[
        'tsa-repo-api',
        'sqlalchemy',
        'alembic'
    ],
    extras_require={
        'dev': [
            'sqlalchemy-stubs'
        ]
    },
    setup_requires=[
        'setuptools-pep8'
    ]
)
