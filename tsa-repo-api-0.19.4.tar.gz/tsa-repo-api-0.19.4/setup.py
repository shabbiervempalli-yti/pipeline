
from setuptools import setup, find_namespace_packages
import versioneer

setup(
    name='tsa-repo-api',
    version=versioneer.get_version(),
    cmdclass=versioneer.get_cmdclass(),
    description='Time series analytics repository api',
    url='https://github.com/waylayio/TS_Analytics.git',
    author='Sander Vanhove, Sam Persoon, Thomas De Smedt',
    author_email='sander.vanhove@waylay.io, sam.persoon@waylay.io, thomas@waylay.io',
    packages=find_namespace_packages(include=['tsa.repo.*']),
    package_data={"tsa.repo.api": ["py.typed"]},
    include_package_data=True,
    install_requires=[
        'typing-extensions',
        'tatsu==4.4.0'  # highest version supported on python 3.7, but has `collections.abc` deprecation warnings
    ],
    extras_require={
        'dev': [
        ]
    },
    setup_requires=[
        'setuptools-pep8'
    ]
)
