
from datetime import datetime
from typing import (
    Union, Optional,
    Any, Dict, List, Tuple, Type, Callable,
    cast, TypeVar
)
from dataclasses import is_dataclass, asdict, dataclass, field, replace
from typing_extensions import Protocol, runtime_checkable

# # TODO: when mypy supports recursive types ...
# JsonDict = Dict[str, 'JsonValue']
# JsonList = List['JsonValue']
JsonScalar = Union[str, int, float, bool, None]
JsonDict = Dict[str, Any]
JsonList = List[Any]
Json = Union[JsonList, JsonDict]
JsonValue = Union[JsonScalar, JsonDict, JsonList]


@dataclass(frozen=True)
class JsonOptions:
    repo_root: str = ''
    excludes: List[str] = field(default_factory=list)
    link_excludes: List[str] = field(default_factory=list)
    embedding_excludes: List[str] = field(default_factory=list)

    def with_exclude(self, *args: str):
        return replace(self, excludes=self.excludes + list(args))

    def without_link(self, *args: str):
        return replace(self, link_excludes=self.link_excludes + list(args))

    def without_embedding(self, *args: str):
        return replace(self, embedding_excludes=self.embedding_excludes + list(args))

    def with_repo_root(self, repo_root: str):
        return replace(self, repo_root=repo_root)

    def filter(self, value: JsonValue):
        if isinstance(value, List):
            for item in value:
                self.filter(cast(JsonValue, item))
            return value
        if isinstance(value, Dict):
            for excl in self.excludes:
                if excl in value:
                    del value[excl]
            return value
        return value

    def add_item_to(self, target: JsonDict, key: str, value: 'JsonLike'):
        if value is not None and key not in self.excludes:
            target[key] = as_json_obj(value, self)


DEFAULT_OPTIONS = JsonOptions()


@runtime_checkable
class HasJsonRepresentation(Protocol):
    def as_json_obj(self, opts: Optional[JsonOptions] = None) -> JsonValue: ...


JsonLike = Union[JsonValue, HasJsonRepresentation]


def as_json_obj(obj: JsonLike, opts: Optional[JsonOptions] = None) -> JsonValue:
    if isinstance(obj, HasJsonRepresentation):
        return obj.as_json_obj(opts=opts)
    if is_dataclass(obj):
        return opts.filter(asdict(obj)) if opts is not None else asdict(obj)
    return opts.filter(obj) if opts is not None else obj


JT = TypeVar('JT', bound=JsonValue)


def as_json_obj_of_type(obj:  JsonLike, json_type: Type[JT], opts: Optional[JsonOptions] = None) -> JT:
    json_obj = as_json_obj(obj, opts)
    if isinstance(json_obj, json_type):
        return json_obj
    raise AttributeError(f"Cannot convert '{json_obj}' to '{json_type}'")
