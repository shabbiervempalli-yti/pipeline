from urllib.parse import urlsplit, parse_qs, urlunsplit, urlencode, quote, unquote
from dataclasses import dataclass, replace
from abc import abstractmethod
from typing import List, Optional, Union, Tuple, cast, Iterator, TypeVar, Type
from typing_extensions import Protocol, runtime_checkable
import re
from uuid import UUID

from .message import RepositoryError
from .json import JsonOptions, JsonDict
from .constants import URL_PARAM_KEYS, HAL


R = TypeVar('R', bound='Ref')


class Ref:
    """Base class for reference objects in the repository"""

    def with_repo_root(self: R, repo_root) -> R:
        return replace(self, repo_root=repo_root)

    def with_library(self: R, library) -> R:
        return replace(self, library=library)

    def as_url(self, opts: JsonOptions = None) -> str:
        if opts is not None and opts.repo_root is not None:
            return self.with_repo_root(opts.repo_root).url
        return self.url

    @property
    @abstractmethod
    def url(self) -> str: ...

    @property
    @abstractmethod
    def path(self) -> str: ...

    @property
    @abstractmethod
    def data_ref(self) -> 'RepoDataRef': ...

    def __bool__(self) -> bool:
        """A Ref is considered falsy when its path is falsy (i.e. None or the empty string)"""
        return bool(self.path)

    def as_ref(self):
        return self

    @property
    def base_ref(self) -> 'Ref':
        return self

    def __str__(self):
        return self.url

    def __eq__(self, other):
        if not isinstance(other, Ref):
            return False
        return self.url == other.url

    @staticmethod
    def parse(href: str, repo_root: Optional[str] = '', library: str = None) -> 'Ref':
        repo_root, path, library, params = Ref.split_url(href, repo_root, library)
        if URL_PARAM_KEYS.DATA in params:
            return RepoDataRef(path, repo_root, library)
        obj_ref = RepoObjectRef._try_parse(path, repo_root, library)
        if obj_ref:
            return obj_ref
        else:
            return RepoResourceRef(path, None, repo_root, library)

    @staticmethod
    def split_path(path: str) -> Tuple[str, str]:
        if not path:
            return ('', '')
        parts = path.split('/')
        if path.endswith('/'):
            name = parts[-2] + '/'
            parent = '/'.join(parts[:-2]) + '/' if len(parts) > 2 else ''
        else:
            name = parts[-1]
            parent = '/'.join(parts[:-1]) + '/' if len(parts) > 1 else ''
        return (parent, name)

    @staticmethod
    def split_url(
        url: str, repo_root: Optional[str] = '', library: Optional[str] = None
    ) -> Tuple[str, str, Optional[str], dict]:
        """extracts the repo root, path, library and remaining url params from a given url"""
        # parse url
        [scheme, net, path, query, fragment] = urlsplit(url)

        # parse repo_root url
        [r_scheme, r_net, r_path, r_q, r_f] = urlsplit(repo_root)

        # if the path has the repo_root path as prefix, remove this prefix
        if r_path and cast(str, path).startswith(cast(str, r_path)):
            path = path[len(r_path):]

        # reconstruct the repository root, using the scheme and host of the input url
        repo_root_parts = cast(Tuple[str, str, str, str, str], (scheme or r_scheme, net or r_net, r_path, r_q, r_f))
        repo_root = urlunsplit(repo_root_parts)

        # extract library param from query params
        query_params = parse_qs(query, keep_blank_values=True)
        lib_params = query_params.pop(URL_PARAM_KEYS.LIBRARY, None)

        # return the repo root, the resource path, library and remaining query params.
        return (repo_root, unquote(path), lib_params[0] if lib_params else library, query_params)

    @staticmethod
    def _construct_url(repo_root: str, path: str, params=None):
        return repo_root + quote(path, safe='/') + ('?' + urlencode(params) if params else '')

    @staticmethod
    def _assert_valid_repo_root(repo_root: Optional[str]):
        """validate a repo root to be an url not ending in a slash"""
        if not isinstance(repo_root, str):
            raise TypeError(f"repo_root must be of type 'str', but has type ({type(repo_root)})")
        [rr_scheme, rr_net, rr_path, rr_q, rr_f] = urlsplit(repo_root)
        if rr_q or rr_f or (rr_path and rr_path[-1] == '/'):
            raise ValueError(f"repo_root must be an absolute or relative path not ending in a '/': {repo_root}")


@runtime_checkable
class HasRef(Protocol):
    def as_ref(self) -> Ref: ...


@dataclass(frozen=True, eq=False)
class AnyRef(Ref):
    any_url: str
    repo_root: Optional[str] = ''
    library: Optional[str] = ''

    def __post_init__(self):
        Ref._assert_valid_repo_root(self.repo_root)

    @property
    def url(self) -> str:
        return self.any_url

    @property
    def path(self) -> str:
        [scheme, net, path, query, fragment] = urlsplit(self.any_url)
        return path

    @property
    def data_ref(self) -> 'RepoDataRef':
        return RepoDataRef(self.path, '')

    def __bool__(self) -> bool:
        return bool(self.any_url)


NO_REF = AnyRef('')

RefLike = Union[Ref, HasRef, str]


def as_ref(target: RefLike, repo_root: Optional[str] = '', library: str = None) -> Ref:
    if target is None:
        raise RepositoryError('Reference cannot be None')
    if isinstance(target, Ref):
        return target
    if isinstance(target, HasRef):
        return target.as_ref()
    if isinstance(target, str):
        return Ref.parse(target, repo_root=repo_root, library=library)
    return Ref.parse(str(target), repo_root=repo_root, library=library)


def as_object_ref(target: RefLike, repo_root: Optional[str] = '', library: str = None) -> 'RepoObjectRef':
    ref = as_ref(target, repo_root, library)
    if isinstance(ref, RepoObjectRef):
        return ref
    raise RepositoryError(f"Invalid Object Reference: {target}")


def as_resource_ref(target: RefLike, repo_root: Optional[str] = '', library: str = None) -> 'RepoResourceRef':
    ref = as_ref(target, repo_root, library)
    if isinstance(ref, RepoResourceRef):
        return ref
    raise RepositoryError(f"Invalid Resource Reference: {target}")


def as_data_ref(target: RefLike, repo_root: Optional[str] = '', library: str = None) -> 'RepoDataRef':
    ref = as_ref(target, repo_root, library)
    if isinstance(ref, RepoDataRef):
        return ref
    return RepoDataRef(ref.path, repo_root, library)


OBJ_REF_REGEX = re.compile(r'^(\/object\/([^\/]*)\/([^\/]*))|([0-f]{8}-[0-f]{4}-[0-f]{4}-[0-f]{4}-[0-f]{12})$')


@dataclass(eq=False)
class RepoObjectRef(Ref):
    """Reference to a repository object"""
    library: str
    uuid: UUID
    repo_root: Optional[str] = ''

    def __post_init__(self):
        Ref._assert_valid_repo_root(self.repo_root)
        if not isinstance(self.uuid, UUID):
            raise TypeError(f"object uuid representation must be of type 'UUID', was '{type(uuid)}'")

    @property
    def url(self) -> str:
        return (self.repo_root or '') + self.path

    @property
    def path(self) -> str:
        return f"/object/{self.library}/{self.uuid}"

    @property
    def data_ref(self) -> 'RepoDataRef':
        return RepoDataRef(self.path, self.repo_root, self.library)

    @staticmethod
    def _try_parse(
        ref: Union[str, JsonDict, UUID],
        repo_root: Optional[str] = '',
        library: str = None
    ) -> Optional['RepoObjectRef']:
        if isinstance(ref, UUID):
            if library:
                return RepoObjectRef(library, ref, repo_root)
            raise RepositoryError(f"Repository object reference '{ref}' requires a library to be specified.")
        if isinstance(ref, dict):
            for key in HAL.OBJ_REF_KEYWORDS:
                if key in ref:
                    ref = ref[key]
                    break
        if not isinstance(ref, str):
            return None
        repo_root, path, library, params = Ref.split_url(ref, repo_root, library)
        match = OBJ_REF_REGEX.match(path)
        if match:
            lib_url, lib_part, uuid_part, uuid = match.groups()
            if library and lib_part and library != lib_part:
                raise RepositoryError(f"Repository object url '{path}' conflicts with library: '{library}'")
            return RepoObjectRef(
                library=library or lib_part,
                uuid=UUID(uuid_part or uuid),
                repo_root=repo_root
            )
        else:
            return None

    @staticmethod
    def parse(ref: Union[str, JsonDict, UUID], repo_root: Optional[str] = '', library: str = None) -> 'RepoObjectRef':
        obj_ref = RepoObjectRef._try_parse(ref, repo_root, library)
        if obj_ref is None:
            raise RepositoryError(f"Invalid repository object reference '{ref}'")
        return obj_ref


@dataclass(eq=False)
class RepoResourceRef(Ref):
    """Reference to a repository entity path"""
    name: str
    parent_path: Optional[str] = ''
    repo_root: Optional[str] = ''
    library: Optional[str] = None

    def __post_init__(self):
        Ref._assert_valid_repo_root(self.repo_root)
        [name_path, self.name] = Ref.split_path(self.name)
        self.parent_path = name_path if self.parent_path is None else self.parent_path + name_path

        if self.is_root and self.parent_path:  # not None or empty string
            raise RepositoryError(
                f"Invalid repository reference: Root path cannot have a parent path: '{self.parent_path}")

        if not self.is_root and not (self.parent_path and self.parent_path.endswith('/')):
            raise RepositoryError(f"Invalid repository reference: '{self.parent_path}' is not a valid parent path")

    @property
    def is_parent(self) -> bool:
        return self.name.endswith('/')

    @property
    def is_root(self) -> bool:
        return self.name == '/'

    @property
    def path(self) -> str:
        return (self.parent_path or '') + self.name

    @property
    def url(self) -> str:
        return Ref._construct_url(self.repo_root or '', self.path, list(self._iter_url_params()))

    def _iter_url_params(self) -> Iterator[Tuple[str, str]]:
        if self.library:
            yield (URL_PARAM_KEYS.LIBRARY, self.library)

    @property
    def data_ref(self) -> 'RepoDataRef':
        return RepoDataRef(self.path, self.repo_root, self.library)

    @property
    def parent(self) -> Optional['RepoResourceRef']:
        """Return the parent path reference, or None if this is the root"""
        if self.is_root:
            return None
        return RepoResourceRef(
            self.parent_path or '',
            '',
            self.repo_root,
            self.library
        )

    def child(self, name) -> 'RepoResourceRef':
        """Create a reference to a child resource, or raise an error when this is not a parent path"""
        if self.is_parent:
            return RepoResourceRef(
                name,
                self.path,
                self.repo_root,
                self.library
            )
        raise RepositoryError(f"Cannot create a child reference on non-parent path '{self.path}'")

    def with_path(self, path) -> 'RepoResourceRef':
        """Create a reference to with another path"""
        return RepoResourceRef(
            path,
            None,
            self.repo_root,
            self.library
        )

    @staticmethod
    def parse(url: str, repo_root: Optional[str] = '', library=None) -> 'RepoResourceRef':
        repo_root, path, library, params = Ref.split_url(url, repo_root, library)
        return RepoResourceRef(path, '', repo_root, library)


@dataclass(eq=False)
class RepoDataRef(Ref):
    base_path: str
    repo_root: Optional[str] = ''
    library: Optional[str] = ''

    def __post_init__(self):
        Ref._assert_valid_repo_root(self.repo_root)
        self.base_path = self.base_path.split('?')[0]

    @property
    def path(self) -> str:
        return self.base_path

    @property
    def data_ref(self) -> 'RepoDataRef':
        return self

    @property
    def base_ref(self) -> Ref:
        obj_ref = RepoObjectRef._try_parse(self.path, self.repo_root or '', self.library)
        if obj_ref:
            return obj_ref
        else:
            return RepoResourceRef(self.path, None, self.repo_root, self.library)

    @property
    def url(self) -> str:
        return Ref._construct_url(self.repo_root or '', self.path, list(self._iter_url_params()))

    def _iter_url_params(self) -> Iterator[Tuple[str, str]]:
        yield (URL_PARAM_KEYS.DATA, '')
        if self.library:
            yield (URL_PARAM_KEYS.LIBRARY, self.library)

    @staticmethod
    def parse(url: str, repo_root: Optional[str] = '', library=None) -> 'RepoResourceRef':
        repo_root, path, library, params = Ref.split_url(url, repo_root, library)
        return RepoResourceRef(path, repo_root, library)
