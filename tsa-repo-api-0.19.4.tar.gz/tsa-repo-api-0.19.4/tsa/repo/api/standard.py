"""definition of standardized references"""
from typing import Optional

from .refs import RepoResourceRef, RefLike, as_ref, as_resource_ref


class RELATIONS:
    """Resource path definitions for standard relations"""
    PATH = RepoResourceRef('/std/rel/')
    SELF = PATH.child('self')
    OBJECT = PATH.child('object')
    RESOURCE = PATH.child('resource')
    DATA = PATH.child('data')
    CHILD = PATH.child('children')
    PARENT = PATH.child('parent')

    @staticmethod
    def as_ref(like: RefLike) -> RepoResourceRef:
        if isinstance(like, str) and not like.startswith('/'):
            return RELATIONS.PATH.child(like)
        else:
            return as_resource_ref(like)


as_rel_ref = RELATIONS.as_ref


class GENERIC_KINDS:
    """Resource path definitions for standard repository item kinds"""
    PATH = RepoResourceRef('/std/kind/')
    JSON = PATH.child('json')
    STRING = PATH.child('string')
    BINARY = PATH.child('binary')

    @staticmethod
    def as_ref(kind_like: RefLike) -> RepoResourceRef:
        if isinstance(kind_like, str) and not kind_like.startswith('/'):
            return GENERIC_KINDS.PATH.child(kind_like)
        else:
            return as_resource_ref(kind_like or GENERIC_KINDS.JSON)


as_kind_ref = GENERIC_KINDS.as_ref
