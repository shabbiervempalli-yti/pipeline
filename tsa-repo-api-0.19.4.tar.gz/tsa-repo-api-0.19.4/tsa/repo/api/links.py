from collections import defaultdict, OrderedDict
from dataclasses import dataclass, field, replace
from typing import List, Iterator, Optional, Dict, Union, Tuple

from .constants import HAL
from .standard import RELATIONS, GENERIC_KINDS, as_kind_ref, as_rel_ref
from .refs import Ref, RefLike, as_ref, RepoResourceRef
from .json import JsonOptions, JsonDict


@dataclass
class Link:
    """Relation link between two repository entities"""
    relation: RepoResourceRef
    ref: Ref
    kind: Optional[RepoResourceRef] = None

    def as_json_obj(self, opts: Optional[JsonOptions] = None) -> JsonDict:
        """HAL representation of the link"""
        return dict([self.rel_link(opts)])

    def rel_link(self, opts: JsonOptions = None) -> Tuple[str, JsonDict]:
        link_obj = dict(href=self.ref.as_url(opts))
        if self.kind is not None and self.kind is not GENERIC_KINDS.JSON:
            link_obj[HAL.LINK_TYPE] = self.kind.name
        return (self.relation.name, link_obj)

    def as_ref(self) -> Ref:
        return self.ref

    def __eq__(self, other):
        return self.ref == other.ref and self.relation == other.relation


def _as_link(relation: RefLike, target: RefLike, kind: Optional[RefLike] = None) -> Link:
    return Link(as_rel_ref(relation), as_ref(target), as_kind_ref(kind) if kind else None)


@dataclass
class LinkCollection:
    links: List[Link] = field(default_factory=list)

    def add_link(self, rel: RefLike, ref: RefLike, kind: RefLike = None):
        self.links.append(_as_link(rel, ref, kind))

    def remove_link(self, rel: RefLike, ref: RefLike):
        self.links.remove(_as_link(rel, ref))

    def with_link(self, rel: RefLike, ref: RefLike, kind: RefLike = None) -> 'LinkCollection':
        self.add_link(rel, ref, kind)
        return self

    def without_link(self, rel: RefLike, ref: RefLike) -> 'LinkCollection':
        self.remove_link(rel, ref)
        return self

    def add_links(self, other: 'LinkCollection'):
        self.links.extend(other.links)

    def _add_links_to(self, other: 'LinkCollection') -> 'LinkCollection':
        other.add_links(self)
        return other

    def as_json_obj(self, opts: Optional[JsonOptions] = None) -> JsonDict:
        """HAL representation of the link collection"""
        link_collection: Dict[str, Dict[str, dict]] = defaultdict(OrderedDict)
        for link in self.links:
            rel, link_obj = link.rel_link(opts)
            if opts and rel not in opts.link_excludes:
                link_collection[rel][link_obj[HAL.LINK_HREF]] = link_obj
        return {
            HAL.LINKS: OrderedDict(
                (rel, links if len(links) > 1 else links[0])
                for rel, link_obj_by_url in link_collection.items()
                for links in [list(link_obj_by_url.values())]
            )
        }

    def iter_refs(self, rel: RefLike = None) -> Iterator[Ref]:
        if rel:
            rel_ref = as_rel_ref(rel)
            for link in self.links:
                if link.relation == rel_ref:
                    yield link.ref
        else:
            for link in self.links:
                yield link.ref

    LinkJson = Dict[str, str]
    LinksJson = Dict[str, Union[LinkJson, List[LinkJson]]]

    def parse_links(self, links_payload: LinksJson):
        for rel, links in links_payload.items():
            if isinstance(links, list):
                for link in links:
                    self.add_link(rel, link[HAL.LINK_HREF], link.get(HAL.LINK_TYPE))
            elif isinstance(links, dict):
                self.add_link(rel, links[HAL.LINK_HREF], links.get(HAL.LINK_TYPE))
