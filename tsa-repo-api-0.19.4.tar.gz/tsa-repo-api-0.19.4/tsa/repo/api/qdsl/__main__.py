"""tool to check the parsing of query dsl expressions

Example:
  echo 'name:future("asdf")' | python -m tsa.repo.api.qdsl terms

"""
import os
import pwd
import sys
import json
from dataclasses import asdict

from tatsu.util import generic_main
from tsa.repo.api.qdsl import QueryDSL2PredicateParser
from tsa.repo.api.qdsl.qdsl import QDSLParser


def main(filename, start=None, **kwargs):
    if not filename or filename == '-':
        text = sys.stdin.read()
    else:
        with open(filename) as f:
            text = f.read()
    if start == 'terms':
        start = 'start'
    parser = QueryDSL2PredicateParser(current_user=pwd.getpwuid(os.getuid())[0])

    def do_parse():
        if start is None or start == 'predicate':
            return parser.parse_predicate(text)
        return parser.terms_parser().parse(text, rule_name=start)
    print(do_parse())
    return


result = generic_main(main, QDSLParser, name='QDSL')
