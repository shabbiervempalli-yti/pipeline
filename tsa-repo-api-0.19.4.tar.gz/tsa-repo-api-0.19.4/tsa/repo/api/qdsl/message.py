

from tsa.repo.api.message import RepositoryError


class QueryDSLError(RepositoryError):
    pass


class QueryDSLParseError(QueryDSLError):

    def __init__(self, input, target, parse_message, parse_position=None):
        message = f"Invalid {target}: {parse_message}"
        if (parse_position):
            message += f" (position {parse_position})"
        super().__init__(message)
        self.input = input
