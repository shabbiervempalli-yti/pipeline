

from dataclasses import dataclass, field, replace
from typing import List, Dict, Type, Callable, Optional, Union, cast
from collections import defaultdict
from abc import ABC, abstractmethod, abstractproperty
import functools
import datetime
import isodate
import json
import re

from tatsu.exceptions import FailedParse, FailedSemantics
from tatsu.ast import AST

import tsa.repo.api.predicate as pred

from .qdsl import QDSLSemantics, QDSLParser
from .message import QueryDSLError, QueryDSLParseError


class PredicateNotSupported(QueryDSLError):
    pass


class PredicateParserContext(ABC):
    """Parser context argument for the `as_predicte` transformation from query term AST to predicate AST"""
    @abstractmethod
    def resolve_username(self, username: str) -> str:
        """Translate a token representing a user in the query string to a user id as stored in the repo database."""
        raise NotImplementedError

    @abstractmethod
    def parse_timestamp_range(self, input: str) -> AST:
        """Parse a timestamp range token to an AST node having `before` and `after` properties of type `datetime`"""
        raise NotImplementedError

    @abstractmethod
    def parse_timestamp(self, input: str) -> datetime.datetime:
        """Parse a timestamp token to `datetime`"""
        raise NotImplementedError


@dataclass
class Qualifier:
    name: str
    include: bool = True

    def __str__(self):
        return f"{'-' if not self.include else ''}{self.name}"


class Matcher(ABC):
    """
    Parse target for the comma seperated tokens after a qualifier and operator in a query term.
    Either the content of a quoted string, a single match term, or a single function with argument terms
    """
    @abstractmethod
    def as_predicate(self, context: PredicateParserContext, term: 'Term'):
        ...


@dataclass
class Term:
    """Parse target for one term in the query DSL ( <qualifier><operator><matchers> )"""
    qualifier: Qualifier
    operator: str = ':'
    matchers: List[Matcher] = field(default_factory=list)

    @property
    def default_matcher_class(self):
        return EqualsMatcher

    @classmethod
    def handles_ast(cls, term_ast: AST) -> bool:
        return False

    def as_predicate(self, context: PredicateParserContext):
        raise PredicateNotSupported(f"Search term not supported: '{self}'")

    def _matchers_predicate(self, context):
        return pred.all(matcher.as_predicate(context, self) for matcher in self.matchers)

    def __str__(self):
        return f"{self.qualifier}{self.operator}{','.join(str(m) for m in self.matchers)}"


@dataclass
class WordMatcher(Matcher):
    arg: str
    quoted: bool = False

    def as_predicate(self, context: PredicateParserContext, term: Term) -> pred.Predicate:
        return term.default_matcher_class(args=[self.arg]).as_predicate(context, term)

    def __str__(self):
        if self.quoted:
            if '"' in self.arg and "'" not in self.arg:
                return f"'{self.arg}'"
            if '"' in self.arg or "'" not in self.arg:
                return json.dumps(self.arg)
            return f'"{self.arg}"'
        return f'{self.arg}'


@dataclass
class FunctionMatcher(Matcher):
    name: Optional[str] = None
    args: List[str] = field(default_factory=list)

    def __str__(self):
        return f"{self.name}({','.join(self.args)})"

    @classmethod
    def handles_ast(cls, matcher_ast: AST):
        return False

    @property
    def _single_arg(self):
        if len(self.args) != 1:
            raise PredicateNotSupported(f"Matcher '{self.name}' only supports a single argument")
        return self.args[0]

    def as_predicate(self, context: PredicateParserContext, term: Term) -> pred.Predicate:
        raise PredicateNotSupported(f"Function matcher '{self.name}' is not supported")


@dataclass
class EqualsMatcher(FunctionMatcher):
    name: str = 'equals'

    @classmethod
    def handles_ast(cls, matcher_ast: AST):
        return matcher_ast.function == 'equals'

    def as_predicate(self, context: PredicateParserContext, term: Term) -> pred.Predicate:
        if isinstance(term, TimestampTerm):
            return pred.Datetime(same_time=context.parse_timestamp(self._single_arg))
        return pred.String(eq=self._single_arg)


@dataclass
class LikeMatcher(FunctionMatcher):
    name: str = 'like'

    @classmethod
    def handles_ast(cls, matcher_ast: AST):
        return matcher_ast.function == 'like'

    def as_predicate(self, context: PredicateParserContext, term: Term) -> pred.Predicate:
        if isinstance(term, TimestampTerm):
            return pred.Datetime(same_date=context.parse_timestamp(self._single_arg))
        return pred.String(like=self._single_arg.replace('*', '%').replace('?', '_'))


@dataclass
class ContainsStringMatcher(FunctionMatcher):
    name: str = 'contains'

    @classmethod
    def handles_ast(cls, matcher_ast: AST):
        args = matcher_ast.arguments
        # single argument that is not a json-string
        return matcher_ast.function == 'contains' and args and \
            len(args) == 1 and args[0] and \
            args[0][0] not in ['{', '"', '[']

    def as_predicate(self, context: PredicateParserContext, term: Term) -> pred.Predicate:
        return pred.String(like=f"%{self._single_arg}%")


class ContainsJsonMatcher(FunctionMatcher):
    name: str = 'contains-json'

    @classmethod
    def handles_ast(cls, matcher_ast: AST):
        return matcher_ast.function == 'contains-json' or (
            matcher_ast.function == 'contains' and not ContainsStringMatcher.handles_ast(matcher_ast)
        )

    def as_predicate(self, context: PredicateParserContext, term: Term) -> pred.Predicate:
        json_args = [
            (json.loads(arg) if arg[0] in ['{', '"', '['] else arg)
            for arg in self.args if arg
        ]
        if len(json_args) == 1:
            return pred.Contains(json_args[0])
        return pred.Contains(json_args)


@dataclass
class UserEqualsMatcher(FunctionMatcher):
    name: str = 'user-equals'

    @classmethod
    def handles_ast(cls, matcher_ast: AST):
        return matcher_ast.function == 'user-equals'

    def as_predicate(self, context: PredicateParserContext, term: Term) -> pred.Predicate:
        return pred.String(eq=context.resolve_username(self._single_arg))


@dataclass
class InPeriodMatcher(FunctionMatcher):
    name: str = 'in-period'

    @classmethod
    def handles_ast(cls, matcher_ast: AST):
        return matcher_ast.function == 'in-period'

    def as_predicate(self, context: PredicateParserContext, term: Term) -> pred.Predicate:
        ts_range = context.parse_timestamp_range(self._single_arg)

        if isinstance(ts_range.after, datetime.timedelta):
            if isinstance(ts_range.before, datetime.datetime):
                return pred.Datetime(
                    after=ts_range.before - ts_range.after,
                    before=ts_range.before
                )
            raise PredicateNotSupported(
                f"Invalid time range: second component should be a timestamp when first is an iso duration."
            )

        if isinstance(ts_range.before, datetime.timedelta):
            if isinstance(ts_range.after, datetime.datetime):
                return pred.Datetime(
                    after=ts_range.after,
                    before=ts_range.after + ts_range.before
                )
            raise PredicateNotSupported(
                f"Invalid time range: first component should be a timestamp when second is an iso duration."
            )

        return pred.Datetime(before=ts_range.before, after=ts_range.after)


def wrap_parse_failure(target):
    def wrap(f):
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            try:
                return f(*args, **kwargs)
            except FailedParse as e:
                raise QueryDSLParseError(input, target, e.message, e.pos) from e
            except (TypeError, ValueError) as e:
                raise QueryDSLParseError(input, target, str(e)) from e
        return wrapper
    return wrap


@dataclass
class Terms:
    terms: List[Term] = field(default_factory=list)

    @wrap_parse_failure('predicate')
    def as_predicate(self, context: PredicateParserContext) -> pred.Predicate:
        predicates_by_qualifier: \
            Dict[bool, Dict[str, List[pred.Predicate]]] = defaultdict(lambda: defaultdict(list))
        for term in self.terms:
            term_qual = term.qualifier
            term_pred = term.as_predicate(context)
            if term_pred:
                predicates_by_qualifier[term_qual.include][term_qual.name].append(term_pred)
        return pred.all(
            (pred.any(includes) for includes in predicates_by_qualifier[True].values()),
            (pred.none(excludes) for excludes in predicates_by_qualifier[False].values())
        )

    def __str__(self):
        return ' '.join(str(t) for t in self.terms)


@dataclass
class NameTerm(Term):

    @classmethod
    def handles_ast(cls, term_ast: AST) -> bool:
        return term_ast.qualifier.name == 'name'

    @property
    def default_matcher_class(self):
        return ContainsStringMatcher

    def as_predicate(self, context: PredicateParserContext) -> pred.Predicate:
        return pred.RepoResource(path=pred.Path(name=self._matchers_predicate(context)))


@dataclass
class UserTerm(Term):

    @classmethod
    def handles_ast(cls, term_ast: AST) -> bool:
        return term_ast.qualifier.name == 'user'

    @property
    def default_matcher_class(self):
        return UserEqualsMatcher

    def as_predicate(self, context: PredicateParserContext) -> pred.Predicate:
        user_created_predicate = pred.Audit(user_created=self._matchers_predicate(context))
        user_modified_predicate = pred.Audit(user_modified=self._matchers_predicate(context))
        return pred.any(
            pred.RepoResource(audit=user_created_predicate),
            pred.RepoResource(audit=user_modified_predicate),
            pred.RepoObject(audit=user_created_predicate),
            pred.RepoObject(audit=user_modified_predicate)
        )


@dataclass
class TimestampTerm(Term):

    @classmethod
    def handles_ast(cls, term_ast: AST) -> bool:
        return term_ast.qualifier.name in ['created', 'modified']

    @property
    def default_matcher_class(cls):
        return InPeriodMatcher

    def as_predicate(self, context: PredicateParserContext) -> pred.Predicate:
        audit_pred_matcher = self._matchers_predicate(context)
        if self.qualifier.name == 'created':
            # do not use the 'created' timestamp on the object (objects can be recreated on put)
            return pred.RepoResource(audit=pred.Audit(timestamp_created=audit_pred_matcher))
        if self.qualifier.name == 'modified':
            return pred.any(
                pred.RepoResource(audit=pred.Audit(timestamp_modified=audit_pred_matcher)),
                pred.RepoObject(audit=pred.Audit(timestamp_modified=audit_pred_matcher))
            )
        raise PredicateNotSupported(f"Qualifier '{self.qualifier.name}' is not supported.")


@dataclass
class DataKeywordTerm(Term):

    DATA_KEY = 'data'
    DATA_ROOT_KEY = 'data.'
    ROOT_KEY = '.'

    @classmethod
    def handles_ast(cls, term_ast: AST) -> bool:
        q_name = term_ast.qualifier.name
        # handles the 'remaining' cases
        return q_name == cls.DATA_KEY or \
            q_name.startswith(cls.ROOT_KEY) or \
            q_name.startswith(cls.DATA_ROOT_KEY)

    @property
    def match_path(self) -> str:
        path = self.qualifier.name
        if path == self.DATA_KEY:
            return ''
        if path.startswith(self.DATA_ROOT_KEY):
            return path[len(self.DATA_KEY):]
        return path

    def as_predicate(self, context: PredicateParserContext) -> pred.Predicate:
        return pred.RepoObject(
            data=pred.At(self.match_path, self._matchers_predicate(context))
        )


@dataclass
class MetadataKeywordTerm(Term):

    META_KEY = 'meta'
    META_ROOT_KEY = 'meta.'

    @classmethod
    def handles_ast(cls, term_ast: AST) -> bool:
        q_name = term_ast.qualifier.name
        return q_name == cls.META_KEY or q_name.startswith(cls.META_ROOT_KEY)

    @property
    def match_path(self) -> str:
        path = self.qualifier.name
        if path == self.META_KEY:
            return ''
        if path.startswith(self.META_ROOT_KEY):
            return path[len(self.META_KEY):]
        return path

    def as_predicate(self, context: PredicateParserContext) -> pred.Predicate:
        # currently only matching meta on the path itself
        return pred.RepoResource(
            meta=pred.At(self.match_path, self._matchers_predicate(context))
        )


@dataclass
class TagsTerm(MetadataKeywordTerm):

    @classmethod
    def handles_ast(cls, term_ast: AST) -> bool:
        return term_ast.qualifier.name == 'tag'

    @property
    def match_path(self) -> str:
        return ".tags[*]"


DEFAULT_MATCHER_CLASSES = [
    EqualsMatcher,
    LikeMatcher,
    ContainsStringMatcher,
    ContainsJsonMatcher,
    InPeriodMatcher
]

DEFAULT_TERM_CLASSES = [
    NameTerm,
    UserTerm,
    TimestampTerm,
    TagsTerm,
    MetadataKeywordTerm,
    DataKeywordTerm
]


def wrap_parse_implementation_failure(f):
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except (ValueError, TypeError) as e:
            raise FailedSemantics(str(e)) from e
    return wrapper


class Semantics(QDSLSemantics):
    """Semantics plugin for the tatsu ebnf parser that converts the raw AST information into AST objects"""

    # stricter regular expression than used in the parser, to allow for more precise error handling
    ISO_8601_TIMESTAMP_RE = re.compile(r'^\d\d\d\d-\d\d-\d\d([T ]\d\d:\d\d(:\d\d(.\d+)?)?)?(Z|[+-]\d\d:\d\d)?$')
    ISO_8601_DURATION_RE = re.compile(r'^[+-]?P(\d+[YMWD])*(T(\d+[HMS])*)?$')
    EPOCH_MILLIS_RE = re.compile(r'^\d{13}$')
    EPOCH_SECONDS_RE = re.compile(r'^\d{10,11}$')

    def __init__(
        self,
        now_callback: Optional[Callable[[], datetime.datetime]],
        term_classes: List[Type[Term]],
        matcher_classes: List[Type[FunctionMatcher]]
    ):
        self._now_callback = now_callback or (lambda: datetime.datetime.now(tz=datetime.timezone.utc))
        self._term_classes = term_classes
        self._matcher_classes = matcher_classes

    @wrap_parse_implementation_failure
    def qualifier(self, ast) -> Qualifier:
        return Qualifier(ast.name, include=ast.prefix != '-')

    @wrap_parse_implementation_failure
    def match_function(self, ast) -> FunctionMatcher:
        for matcher_class in self._matcher_classes:
            if matcher_class.handles_ast(ast):
                return matcher_class(name=ast.function, args=ast.arguments)
        return FunctionMatcher(name=ast.function, args=ast.arguments)

    @wrap_parse_implementation_failure
    def match_quoted_word(self, ast) -> Matcher:
        return WordMatcher(ast, quoted=True)  # needs to be replaced by the term_class

    @wrap_parse_implementation_failure
    def match_word(self, ast) -> Matcher:
        return WordMatcher(ast, quoted=False)  # needs to be replaced by the term_class

    @wrap_parse_implementation_failure
    def term(self, ast) -> Term:
        for term_class in self._term_classes:
            if term_class.handles_ast(ast):
                return term_class(ast.qualifier, ast.operator, ast.matchers)
        return Term(ast.qualifier, ast.operator, ast.matchers)

    @wrap_parse_implementation_failure
    def start(self, ast) -> Terms:
        return Terms(ast)

    @wrap_parse_implementation_failure
    def now(self, ast) -> datetime.datetime:
        ts = self._now_callback()
        if ast.now_offset:
            if ast.offset_dir == '+':
                return ts + ast.now_offset
            return ts - ast.now_offset
        return ts

    @wrap_parse_implementation_failure
    def iso_datetime_r(self, ast) -> datetime.datetime:
        # parser rule if far more lenient, to allow to capture user errors here:
        if not self.ISO_8601_TIMESTAMP_RE.match(ast):
            raise ValueError(
                f"Timestamp '{ast}' has an incorrect format. " +
                "Use ISO-8601 timestamps such as '2012-12-01' or '2012-12-01T23:01:00Z'."
            )
        tz = isodate.UTC
        time = datetime.time(0)
        if 'T' in ast:
            _date, _time = ast.split('T')
            date = isodate.parse_date(_date)
            time = isodate.parse_time(_time)
            tz = time.tzinfo or tz
        else:
            date = isodate.parse_date(ast)
        return datetime.datetime.combine(date, time, tz)

    # # this iso_datetime_p (parser rule) is an alternative to iso_datetime_r (regex)
    # # that provides cleaner code, but the _p variant is not eager enough to read time parts () ...
    # UPDATE: will probably work now with adding the `$` (end-of-text) to the timestamp_range rule ...
    # def iso_datetime_p(self, ast):
    #     return datetime.datetime.combine(ast.date, ast.time or time(0,0,0) , ast.tz or isodate.UTC)

    # def iso_date(self, ast):
    #     return isodate.parse_date(ast)

    # def iso_time(self, ast):
    #     return isodate.parse_time(ast)

    # def iso_timezone(self, ast):
    #     return isodate.parse_tzinfo(ast or 'Z')

    @wrap_parse_implementation_failure
    def iso_duration(self, ast) -> Union[datetime.timedelta, isodate.Duration]:
        if not self.ISO_8601_DURATION_RE.match(ast):
            raise ValueError(
                f"Duration '{ast}' has an incorrect format. " +
                "Use ISO-8601 duration such as 'P2D' or 'PT1H'."
            )
        return isodate.parse_duration(ast)

    @wrap_parse_implementation_failure
    def epoch_timestamp_millis(self, ast) -> datetime.datetime:
        if not self.EPOCH_MILLIS_RE.match(ast):
            raise ValueError(
                f"Recognized '{ast}' as epoch milliseconds timestamp, but expected 13 digits."
            )
        return datetime.datetime.fromtimestamp(int(ast) / 1000, isodate.UTC)

    @wrap_parse_implementation_failure
    def epoch_timestamp_seconds(self, ast) -> datetime.datetime:
        if not self.EPOCH_SECONDS_RE.match(ast):
            raise ValueError(
                f"Recognized '{ast}' as epoch seconds timestamp, but expected 10 or 11 digits."
            )
        return datetime.datetime.fromtimestamp(int(ast), isodate.UTC)


@dataclass
class QueryDSL2PredicateParser(PredicateParserContext):
    """
    Wrapper around the generated tatsu ebnf parser. Each item kind in the repository
    can have its own set of AST classes to handle specific query terms and matchers.

    The class also provides context to the conversion from query term AST to predicate AST
    (e.g. fix the interpretation of 'now', '@me', or the mapping of username tokens)
    """
    current_user: str
    username_callback: Optional[Callable[[str], Optional[str]]] = None
    now_callback: Optional[Callable[[], datetime.datetime]] = None
    term_classes: List[Type[Term]] = field(default_factory=list)
    matcher_classes: List[Type[FunctionMatcher]] = field(default_factory=list)

    def resolve_username(self, username: str) -> str:
        if username == '@me':
            return self.current_user or username
        if self.username_callback:
            return self.username_callback(username) or username
        return username

    def terms_parser(self) -> QDSLParser:
        return QDSLParser(semantics=Semantics(
            now_callback=self.now_callback,
            term_classes=self.term_classes or DEFAULT_TERM_CLASSES,
            matcher_classes=self.matcher_classes or DEFAULT_MATCHER_CLASSES
        ))

    @wrap_parse_failure('query')
    def parse_terms(self, input: str) -> Terms:
        return self.terms_parser().parse(input)

    @wrap_parse_failure('predicate')
    def parse_predicate(self, input: str) -> pred.RepoPredicate:
        return cast(pred.RepoPredicate, self.parse_terms(input).as_predicate(self))

    @wrap_parse_failure('time range')
    def parse_timestamp_range(self, input: str) -> AST:
        return self.terms_parser().parse(input, rule_name='timestamp_range')

    @wrap_parse_failure('timestamp')
    def parse_timestamp(self, input: str) -> Union[datetime.datetime, datetime.timedelta, isodate.Duration]:
        return self.terms_parser().parse(input, rule_name='timestamp')
