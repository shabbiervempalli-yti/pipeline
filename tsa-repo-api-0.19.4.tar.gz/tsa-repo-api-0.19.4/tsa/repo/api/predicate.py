"""
Abstract Syntax Tree for query predicates used in the repository.
These query predicates form part of the repo API, and so do not contain
any binding to the database layer.
User can construct queries using these objects, or (in most cases) using
the query DSL that converts query strings into this format.
"""
from dataclasses import dataclass, asdict
import re
from typing import (
    TypeVar, Generic, cast,
    Dict, Union, List,
    Optional, Iterable, Iterator
)
from datetime import datetime
from collections import OrderedDict

from .json import JsonValue


class Predicate:
    def as_json_obj(self):
        return asdict(self, dict_factory=OrderedDict)


# Predicate operators: the boolean algebra on predicates

P = TypeVar('P', bound=Predicate, covariant=True)


class PredicateOperator(Generic[P], Predicate):
    ...


@dataclass
class TrueFalsePredicate(Generic[P], PredicateOperator[P]):
    """predicate that is always true or false"""
    value: bool


@dataclass
class And(Generic[P], PredicateOperator[P]):
    _and: List[P]


@dataclass
class Or(Generic[P],  PredicateOperator[P]):
    _or: List[P]


@dataclass
class Not(Generic[P],  PredicateOperator[P]):
    _not: P


PredicateExpression = Union[Predicate, PredicateOperator[Predicate]]

# Field predicates on columns of the database


@dataclass
class String(Predicate):
    like: Optional[str] = None
    eq: Optional[str] = None


StringPredicate = Union[String, PredicateOperator[String]]


@dataclass
class Datetime(Predicate):
    before: Optional[datetime] = None
    after: Optional[datetime] = None
    same_time: Optional[datetime] = None
    same_date: Optional[datetime] = None


DatetimePredicate = Union[Datetime, PredicateOperator[Datetime]]


@dataclass
class Contains(Predicate):
    # jsonb containment: identity on primitive values, unordered subset for arrays, subobject for objects
    contains: Optional[JsonValue] = None


SQLJSON_PATH_RE = re.compile(r'^(\.(\w+(\(\))?|\*|\*\*)|\[[\*|\d+]\])*$')


@dataclass
class At(Generic[P], Predicate):
    """
    Predicated on the content of a JSONB field, at the given path.
    :param str at: a concatenation of SQL/JSON path accessors:
        - `.key` to traverse the object property `key`
        - `[*]` to traverse all items of an array
        - `[n]` (`n` a number) to traverse to the `n`-th item of an array
        - `size()` to access the size of an object or array
        - `.*` to traverse all child objects of an object
        - `.**` to traverse all decscendant objects of an object
        See
[SQL/JSON Path Language](https://www.postgresql.org/docs/12/functions-json.html#FUNCTIONS-SQLJSON-PATH)
        for more examples.
    :param Predicate exists: a predicate to be checked at that path. If missing, the
       existence of the path element is the condition.
    """
    at: str
    exists: Optional[Union[P, PredicateOperator[P]]]

    def __post_init__(self):
        if not SQLJSON_PATH_RE.match(self.at):
            raise ValueError(
                f"Path expression '{self.at}' has an incorrect format. "
            )

# Item predicates on column groups


class ItemPredicate(Predicate):
    ...


@dataclass
class Audit(ItemPredicate):
    """Predicate for the created or modified user/timestamp of a resource or object"""
    timestamp_created: Optional[DatetimePredicate] = None
    user_created: Optional[StringPredicate] = None
    timestamp_modified: Optional[DatetimePredicate] = None
    user_modified: Optional[StringPredicate] = None


@dataclass
class Path(ItemPredicate):
    """Predicate on the resource location of a repository item"""
    name: Optional[StringPredicate] = None
    path: Optional[StringPredicate] = None
    parent_path: Optional[StringPredicate] = None


AuditPredicate = Union[Audit, PredicateOperator[Audit]]
PathPredicate = Union[Path, PredicateOperator[Path]]


@dataclass
class RepoResource(ItemPredicate):
    """Predicate on a repository resource (path information, meta data and audit information)"""
    meta: Optional[PredicateExpression] = None
    audit: Optional[AuditPredicate] = None
    path: Optional[PathPredicate] = None


@dataclass
class RepoObject(ItemPredicate):
    """Predicate on a repository object (payload data, payload metadata and audit information"""
    data: Optional[PredicateExpression] = None
    meta: Optional[PredicateExpression] = None
    audit: Optional[AuditPredicate] = None


RepoItem = Union[RepoResource, RepoObject]
RepoPredicate = Union[RepoItem, PredicateOperator[RepoItem]]


# utility methods to construct basic boolean combinations of predicates.

TRUE: PredicateOperator[Predicate] = TrueFalsePredicate(True)
FALSE: PredicateOperator[Predicate] = TrueFalsePredicate(False)


def _flatten(collection: Iterable[Union[P, Iterable[P]]]) -> Iterator[P]:
    for x in collection:
        if isinstance(x, Iterable) and not isinstance(x, (str, bytes)):
            yield from _flatten(x)
        else:
            yield x


def all(*predicates: Union[P, Iterable[P]]) -> Union[P, PredicateOperator[P]]:
    preds = list(p for p in _flatten(predicates) if p != TRUE)
    if FALSE in preds:
        return cast(PredicateOperator[P], FALSE)
    if preds:
        if len(preds) > 1:
            return And(preds)
        return preds[0]
    return cast(PredicateOperator[P], TRUE)  # should return True to be sound -- empty intersection


def any(*predicates: Union[P, Iterable[P]]) -> Union[P, PredicateOperator[P]]:
    preds = list(p for p in _flatten(predicates) if p != FALSE)
    if TRUE in preds:
        return cast(PredicateOperator[P], TRUE)
    if preds:
        if len(preds) > 1:
            return Or(preds)
        return preds[0]
    return cast(PredicateOperator[P], FALSE)  # should return False to be sound -- empty union


def none(predicates: Union[P, Iterable[P]]) -> PredicateOperator[Union[P, PredicateOperator[P]]]:
    any_pred = any(predicates)
    if any_pred is TRUE:
        return cast(PredicateOperator[P], FALSE)
    if any_pred is FALSE:
        return cast(PredicateOperator[P], TRUE)
    return Not(any_pred)
