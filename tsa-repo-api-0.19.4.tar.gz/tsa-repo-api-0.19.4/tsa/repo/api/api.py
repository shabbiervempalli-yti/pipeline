from abc import abstractmethod, ABC
from typing import Any, Iterator, Optional, List
from logging import LogRecord

from .refs import RefLike, Ref, RepoResourceRef
from .links import LinkCollection
from .payload import RepoObject, RepoResource
from .json import JsonValue, JsonList
from .predicate import RepoPredicate


class Repository(ABC):

    @abstractmethod
    def put_resource(self, res: RepoResource, cascade_object=True, as_import=False) -> RepoResource:
        """Store a new repository resource"""
        raise NotImplementedError

    @abstractmethod
    def get_resource(self, ref: RefLike, include_object=True) -> RepoResource:
        """Get the metadata of a repository resource"""
        raise NotImplementedError

    @abstractmethod
    def iter_resource(
        self,
        parent: RefLike = None,
        kinds: Optional[List[RefLike]] = None,
        query: str = None,
        filter: RepoPredicate = None,
        limit: int = None,
        offset: int = 0
    ) -> Iterator[RepoResource]:
        """
        Get all resources that satisfy all given (optional) constraints
        :param Reflike parent: direct descendants of the given (parent) resource (reference)
        :param List[RefLike] kinds: repository kind of the resources
        :param str query: a query string (see tsa.repo.api.qdsl),
            the interpretation can depend on the requested kinds.
        :param RepoPredicate filter: a filter predicate (see tsa.repo.api.predicate)
        :param int limit: maximum number of returned resources, default is system-dependent.
        :param int offset: offset of the returned resources, default to 0
        By default, resources are ordered by path (ascending)
        """
        raise NotImplementedError

    @abstractmethod
    def count_resources(
        self,
        parent: RefLike,
        kinds: Optional[List[RefLike]] = None,
        query: str = None,
        filter: RepoPredicate = None,
    ) -> int:
        """
        Count all resources that satisfy all given (optional) constraints
        :param Reflike parent: direct descendants of the given (parent) resource (reference)
        :param List[RefLike] kinds: repository kind of the resources
        :param str query: a query string (see tsa.repo.api.qdsl), the interpretation can depend on the requested kinds.
        :param RepoPredicate filter: a filter predicate (see tsa.repo.api.predicate)
        """
        raise NotImplementedError

    @abstractmethod
    def delete_resource(
        self,
        ref: RefLike,
        cascade_children=False,
        cascade_object=True
    ) -> LinkCollection:
        """Delete a resource and related entities."""
        raise NotImplementedError

    @abstractmethod
    def get_data(self, ref: RefLike) -> Any:
        """Get the data related to a resource or object"""

    @abstractmethod
    def put_data(self, ref: RefLike, data: Any) -> LinkCollection:
        """Replace the data related to a resource or object"""
        raise NotImplementedError

    @abstractmethod
    def delete_data(self, ref: RefLike) -> LinkCollection:
        """Clear out the data related to a resource or object"""
        raise NotImplementedError

    @abstractmethod
    def post_object(self, obj: RepoObject, as_import=False) -> RepoObject:
        """Store a new repository object"""
        raise NotImplementedError

    @abstractmethod
    def put_object(self, obj: RepoObject, as_import=False) -> RepoObject:
        """Update an existing repository object"""
        raise NotImplementedError

    @abstractmethod
    def get_object(self, ref: RefLike) -> RepoObject:
        """Get the metadata of a repository object"""
        raise NotImplementedError

    @abstractmethod
    def delete_object(self, ref: RefLike) -> LinkCollection:
        """Delete a repository object"""
        raise NotImplementedError
