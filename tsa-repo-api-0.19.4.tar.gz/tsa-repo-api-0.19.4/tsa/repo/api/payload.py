
from dataclasses import dataclass, replace, field, InitVar
from collections import defaultdict, OrderedDict
from abc import abstractmethod, ABC

from typing import (
    Union, Tuple, List,  Dict, Optional, Any,
    TypeVar, Type, TypeVar
)
from uuid import UUID

from .refs import (
    RepoObjectRef, RepoResourceRef,
    Ref, RefLike, HasRef, NO_REF,
    as_resource_ref, as_object_ref
)
from .links import LinkCollection
from .json import (
    JsonDict, JsonLike, JsonList, Json, JsonOptions, JsonValue,
    as_json_obj, as_json_obj_of_type,
    DEFAULT_OPTIONS
)
from .standard import RELATIONS, as_kind_ref, as_rel_ref
from .constants import HAL
from .message import RepositoryError


class RepoItem(ABC, HasRef):
    id_ref: Optional[Ref]

    @property
    def ref(self) -> Ref:
        return self.id_ref or NO_REF

    def as_ref(self) -> Ref:
        return self.id_ref or NO_REF


@dataclass
class Embedding:
    """Embedding link to a repository item"""
    relation: RepoResourceRef
    item: JsonLike

    def __eq__(self, other: object):
        if not isinstance(other, Embedding):
            return False
        if self.relation != other.relation:
            return False
        if isinstance(self.item, HasRef) and isinstance(other.item, HasRef):
            return self.item.as_ref() == other.item.as_ref()
        return self.item == other.item

    def rel_json_obj(self, opts: JsonOptions = None):
        return self.relation.name, as_json_obj(self.item, opts)


@dataclass
class EmbeddingCollection:
    embeddings: List[Embedding] = field(default_factory=list)

    def add_embedding(self, rel: RefLike, item: JsonLike):
        self.embeddings.append(Embedding(as_rel_ref(rel), item))

    def remove_embedding(self, rel: RefLike, ref: JsonLike):
        self.embeddings.remove(Embedding(as_rel_ref(rel), ref))

    def as_json_obj(self, opts: Optional[JsonOptions] = None) -> JsonDict:
        """HAL representation of the embedding collection"""
        embedding_coll: Dict[str, JsonList] = defaultdict(list)
        for embedding in self.embeddings:
            rel, json_obj = embedding.rel_json_obj(opts)
            if opts and rel not in opts.embedding_excludes:
                embedding_coll[rel].append(json_obj)
        if embedding_coll:
            return {HAL.EMBEDDINGS: {
                rel: (embs if len(embs) > 1 else embs[0])
                for rel, embs in embedding_coll.items()
            }}
        return {}

    def add_embeddings(self, other: 'EmbeddingCollection'):
        self.embeddings.extend(other.embeddings)

    def _add_embeddings_to(self, other: 'EmbeddingCollection') -> 'EmbeddingCollection':
        other.add_embeddings(self)
        return other

    def parse_embeddings(self, embedding_payload: JsonDict):
        for rel, embs in embedding_payload.items():
            if isinstance(embs, list):
                for emb in embs:
                    self.add_embedding(rel, emb)
            else:
                self.add_embedding(rel, embs)


@dataclass
class HALResponse(EmbeddingCollection, LinkCollection):

    def parse_hal(self, payload):
        if isinstance(payload, dict):
            if HAL.EMBEDDINGS in payload:
                self.parse_embeddings(payload[HAL.EMBEDDINGS])
            if HAL.LINKS in payload:
                self.parse_links(payload[HAL.LINKS])


def _extract_identifiers(keys, payload, ctx_ids) -> List[str]:
    """
    Read the given keys from payload, or from the attributes section,
    or from the context defaults (normally the url),
    raising an error if they are conflicting.
    """
    root_ids = [payload.get(k) for k in keys]
    if HAL.ATTRIBUTES in payload:
        attr_ids = [payload[HAL.ATTRIBUTES].get(k) for k in keys]
    else:
        attr_ids = list(ctx_ids)
    for idx, key in enumerate(keys):
        id = root_ids[idx] or attr_ids[idx] or ctx_ids[idx]
        if attr_ids[idx] and id != attr_ids[idx]:
            raise RepositoryError(
                f"Conflicting data in representation: "
                f"{HAL.ATTRIBUTES}.{key}='{attr_ids[idx]}' "
                f"versus {key}='{id}'"
            )
        if ctx_ids[idx] and id != ctx_ids[idx]:
            raise RepositoryError(
                f"Conflicting data in representation: "
                f"(url) context: {key}='{ctx_ids[idx]}' "
                f"versus payload: ({HAL.ATTRIBUTES}.){key}='{id}'"
            )
        root_ids[idx] = id
    return root_ids


@dataclass
class RepoObjectBase(RepoItem):
    id_ref: Optional[RepoObjectRef] = None
    data: Optional[Any] = None
    attrs: JsonDict = field(default_factory=dict)
    meta: JsonDict = field(default_factory=dict)

    def __post_init__(self):
        self.id_ref = as_object_ref(self.id_ref) if self.id_ref else None

    @property
    def uuid(self) -> Optional[UUID]:
        return self.id_ref.uuid if self.id_ref else None

    def _add_embeddings_to(self, coll: EmbeddingCollection) -> EmbeddingCollection:
        return coll

    def _add_links_to(self, coll: LinkCollection) -> LinkCollection:
        if self.data is None and self.id_ref is not NO_REF:
            coll.add_link(RELATIONS.DATA, self.ref.data_ref)
        if self.id_ref:
            coll.add_link(RELATIONS.SELF, self.id_ref)
        return coll

    def as_json_obj(self, opts: Optional[JsonOptions] = None) -> JsonDict:
        opts = opts or DEFAULT_OPTIONS

        repr: JsonDict = OrderedDict()
        if self.id_ref and self.id_ref.uuid:
            repr[HAL.UUID] = str(self.id_ref.uuid)
        opts.add_item_to(repr, HAL.DATA, self.data)
        opts.add_item_to(repr, HAL.META, self.meta)
        opts.add_item_to(repr, HAL.ATTRIBUTES, self.attrs)
        if repr[HAL.ATTRIBUTES] and self.id_ref and self.id_ref.library:
            repr[HAL.ATTRIBUTES][HAL.LIBRARY] = self.id_ref.library

        repr.update(self._add_links_to(LinkCollection()).as_json_obj(opts))
        repr.update(self._add_embeddings_to(EmbeddingCollection()).as_json_obj(opts))
        return repr

    @classmethod
    def parse(cls, payload: Optional[JsonDict], repo_root: Optional[str] = '', library: str = None):
        if payload is None:
            return cls()
        if not isinstance(payload, dict):
            raise RepositoryError(f"Invalid Repository Object representation (not a json object)")

        # extract identifying attributes in the representation payload
        repr_uuid, repr_library = _extract_identifiers([HAL.UUID, HAL.LIBRARY], payload, (None, library))

        id_ref = RepoObjectRef(repr_library, UUID(repr_uuid), repo_root) if repr_uuid else None
        repo_obj = cls(id_ref=id_ref)
        if HAL.DATA in payload:
            repo_obj.data = payload[HAL.DATA]
        if HAL.META in payload:
            repo_obj.meta = payload[HAL.META]
        if HAL.ATTRIBUTES in payload:
            repo_obj.attrs = payload[HAL.ATTRIBUTES]
        return repo_obj


@dataclass
class RepoObject(HALResponse, RepoObjectBase):

    def as_json_obj(self, opts: Optional[JsonOptions] = None) -> JsonDict:
        return RepoObjectBase.as_json_obj(self, opts)

    def _add_embeddings_to(self, coll: EmbeddingCollection) -> EmbeddingCollection:
        RepoObjectBase._add_embeddings_to(self, coll)
        EmbeddingCollection._add_embeddings_to(self, coll)
        return coll

    def _add_links_to(self, coll: LinkCollection) -> LinkCollection:
        RepoObjectBase._add_links_to(self, coll)
        LinkCollection._add_links_to(self, coll)
        return coll

    @classmethod
    def parse(cls, payload: Optional[JsonDict], repo_root: Optional[str] = '', library: str = None):
        repo_obj = super().parse(payload, repo_root, library)
        repo_obj.parse_hal(payload)
        return repo_obj


@dataclass
class RepoResourceBase(RepoItem):
    id_ref: RepoResourceRef
    object: Union[None, RepoObject, RepoObjectRef] = None
    attrs: JsonDict = field(default_factory=dict)
    meta: JsonDict = field(default_factory=dict)

    def __post_init__(self):
        self.id_ref = as_resource_ref(self.id_ref)

    @property
    def data(self) -> Any:
        return self.object.data if isinstance(self.object, RepoObject) else None

    @property
    def object_uuid(self) -> Optional[UUID]:
        return self.object.uuid if self.object else None

    def _add_embeddings_to(self, coll: EmbeddingCollection) -> EmbeddingCollection:
        "add the embedding relations owned by this resource to target collection"
        if isinstance(self.object, RepoObject):
            coll.add_embedding(RELATIONS.OBJECT, self.object)
        return coll

    def _add_links_to(self, coll: LinkCollection) -> LinkCollection:
        "add the link relations owned by this resource to target collection"
        if isinstance(self.object, RepoObjectRef):
            coll.add_link(RELATIONS.OBJECT, self.object)
        coll.add_link(RELATIONS.SELF, self.id_ref)
        return coll

    def as_json_obj(self, opts: Optional[JsonOptions] = None) -> JsonDict:
        opts = opts or DEFAULT_OPTIONS
        repr: JsonDict = {}
        if self.id_ref and self.id_ref.name:
            repr[HAL.NAME] = self.id_ref.name

        opts.add_item_to(repr, HAL.DATA, self.data)
        opts.add_item_to(repr, HAL.META, self.meta)
        opts.add_item_to(repr, HAL.ATTRIBUTES, self.attrs)
        if self.id_ref and repr[HAL.ATTRIBUTES]:
            repr[HAL.ATTRIBUTES][HAL.PATH] = self.id_ref.path
            if self.id_ref.library:
                repr[HAL.ATTRIBUTES][HAL.LIBRARY] = self.id_ref.library

        repr.update(self._add_links_to(LinkCollection()).as_json_obj(opts))
        repr.update(self._add_embeddings_to(EmbeddingCollection()).as_json_obj(opts.with_exclude(HAL.DATA)))

        return repr

    @classmethod
    def parse(cls, ctx_ref: RepoResourceRef, payload: Optional[JsonDict]):
        if payload is None:
            return cls(ctx_ref)
        if not isinstance(payload, dict):
            raise RepositoryError(f"Invalid Repository Resource representation (not a json object)")

        # extract identifying attributes from the payload
        repr_name, repr_path, repr_parent, repr_library = _extract_identifiers(
            [HAL.NAME, HAL.PATH, HAL.PARENT, HAL.LIBRARY],
            payload,
            (None, None, None, ctx_ref.library)
        )

        # check path specification in representation
        if repr_path:
            path = repr_path
        elif repr_parent and repr_name:
            path = repr_parent + repr_name
        elif repr_name:
            # use the context reference as root
            if ctx_ref.is_parent:
                path = ctx_ref.path + repr_name  # child
            else:
                path = (ctx_ref.parent_path or '') + repr_name  # sibling
        else:
            path = ctx_ref.path
        # caller will need to inspect if this constructed path is acceptable ...
        id_ref = ctx_ref.with_path(path)

        # parse into object item or object reference
        obj_payload = payload.get(HAL.OBJECT)
        obj, obj_ref = None, None
        if obj_payload:
            obj_ref = RepoObjectRef._try_parse(obj_payload, ctx_ref.repo_root, ctx_ref.library)
            if not obj_ref:
                obj = RepoObject.parse(obj_payload, ctx_ref.repo_root, ctx_ref.library)

        # parse data (into object item)
        data = payload.get(HAL.DATA)
        if data:
            if obj:
                obj.data = data
            elif obj_ref:
                obj = RepoObject(obj_ref, data)
            else:
                obj = RepoObject(None, data)

        # create resource item
        repo_res = cls(
            id_ref=id_ref,
            object=obj or obj_ref,
        )
        if HAL.ATTRIBUTES in payload:
            repo_res.attrs = payload[HAL.ATTRIBUTES]
        if HAL.META in payload:
            repo_res.meta = payload[HAL.META]
        return repo_res


@dataclass
class RepoResource(HALResponse, RepoResourceBase):

    def as_json_obj(self, opts: Optional[JsonOptions] = None) -> JsonDict:
        return RepoResourceBase.as_json_obj(self, opts)

    def _add_embeddings_to(self, coll: EmbeddingCollection) -> EmbeddingCollection:
        RepoResourceBase._add_embeddings_to(self, coll)
        EmbeddingCollection._add_embeddings_to(self, coll)
        return coll

    def _add_links_to(self, coll: LinkCollection) -> LinkCollection:
        RepoResourceBase._add_links_to(self, coll)
        LinkCollection._add_links_to(self, coll)
        return coll

    @classmethod
    def parse(cls, id_ref: RepoResourceRef,  payload: Optional[JsonDict]):
        repo_res = super().parse(id_ref, payload)
        repo_res.parse_hal(payload)
        return repo_res
