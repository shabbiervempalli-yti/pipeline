
from dataclasses import dataclass, field
from typing import Optional, Mapping, Any
from datetime import datetime


@dataclass
class LibraryStatus:
    """Data class representing the technical metadata of a library schema"""
    db: str = field(metadata=dict(width=10))
    id: str = field(metadata=dict(width=36))
    name: str = field(metadata=dict(width=20))
    schema: str = field(metadata=dict(width=33))
    user_created: str = field(metadata=dict(width=10), repr=False)
    timestamp_created: datetime = field(metadata=dict(width=12), repr=False)
    user_modified: str = field(metadata=dict(width=10), repr=False)
    timestamp_modified: datetime = field(metadata=dict(width=12), repr=False)
    target_revision: Optional[str] = field(metadata=dict(width=12))
    schema_exists: Optional[bool] = field(default=None, metadata=dict(width=10))
    revision: Optional[str] = field(default=None, metadata=dict(width=12))
    table_counts: Optional[Mapping[str, int]] = field(default=None, repr=False, metadata=dict(width=10))
