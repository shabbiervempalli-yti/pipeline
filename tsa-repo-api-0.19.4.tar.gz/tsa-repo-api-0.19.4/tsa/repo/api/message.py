
from abc import abstractmethod
from logging import (
    CRITICAL,
    ERROR,
    INFO,
    WARNING,
)
from typing import Any, ContextManager, List

from http import HTTPStatus


class RepositoryError(Exception):
    http_status: HTTPStatus = HTTPStatus.BAD_REQUEST

    @property
    def status_code(self) -> int:
        return self.http_status.value


class RepositoryNotFoundError(RepositoryError):
    http_status = HTTPStatus.NOT_FOUND


class RepositoryNotImplementedError(RepositoryError, NotImplementedError):
    http_status = HTTPStatus.NOT_IMPLEMENTED


class RepositoryDbError(RepositoryError):
    http_status = HTTPStatus.INTERNAL_SERVER_ERROR


class ResultListener:
    """Optional interface for receiving logging, http status and http response attributes"""
    @abstractmethod
    def log(self, level, msg, *args, **kwargs):
        """Receive a log statement"""
        raise RepositoryNotImplementedError

    @abstractmethod
    def status(self, status: HTTPStatus):
        """Receive a http status code"""
        raise RepositoryNotImplementedError

    @abstractmethod
    def attribute(self, key: str, value: Any, **kwargs):
        """Receive a response attribute"""
        raise RepositoryNotImplementedError


class NOOPListener(ResultListener):
    def log(self, level, msg, *args, **kwargs):
        pass

    def status(self, status: HTTPStatus):
        pass

    def attribute(self, key: str, value: Any, **kwargs):
        pass


NOOP_LISTENER = NOOPListener()


class ListenerSource():
    def __init__(self, listener: ResultListener = NOOP_LISTENER, **kwargs):
        self._listener_stack: List[ResultListener] = []
        self.listener = listener

    def set_response_attributes(self, **attrs):
        for key, value in attrs.items():
            self.set_response_attribute(key, value)

    def set_response_attribute(self, key: str, value: str, **kwargs):
        self.listener.attribute(key, value, **kwargs)

    def set_response_status(self, status: HTTPStatus):
        self.listener.status(status)

    def warning(self, msg, *args, **kwargs):
        self.listener.log(WARNING, msg, *args, **kwargs)

    def error(self, msg, *args, **kwargs):
        self.listener.log(ERROR, msg, *args, **kwargs)

    def critical(self, msg, *args, **kwargs):
        self.listener.log(CRITICAL, msg, *args, **kwargs)

    def info(self, msg, *args, **kwargs):
        self.listener.log(INFO, msg, *args, **kwargs)

    def debug(self, msg, *args, **kwargs):
        self.listener.log(INFO, msg, *args, **kwargs)

    def temporary_listener(self, new_listener: ResultListener = NOOP_LISTENER) -> ContextManager:
        """Creates a context manager that overrides the current result listener in its scope"""
        src = self

        class ListenerStack(ContextManager):
            def __enter__(slf):
                src._push_listener(new_listener)

            def __exit__(slf, type, value, traceback):
                src._pop_listener()
        return ListenerStack()

    def silenced_listener(self) -> ContextManager:
        """Creates a context manager that temporarily silences all log, status and response attributes call backs"""
        return self.temporary_listener(NOOP_LISTENER)

    def _push_listener(self, new_listener: ResultListener = NOOP_LISTENER) -> ResultListener:
        old_listener = self.listener
        self._listener_stack.append(old_listener)
        self.listener = new_listener
        return old_listener

    def _pop_listener(self) -> ResultListener:
        old_listener = self.listener
        self.listener = self._listener_stack.pop()
        return old_listener
