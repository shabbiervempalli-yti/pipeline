"""plugins for handling the TSA Query Config Objects"""

from dataclasses import dataclass, field
from typing import List, Type

import tsa.repo.api.qdsl.parser as qdsl
import tsa.repo.api.predicate as pred
from tsa.repo.api.standard import as_kind_ref


KIND = as_kind_ref('tsa_query')


@dataclass
class ResourceTerm(qdsl.Term):
    """parser plugin for the query DSL that provides special handling for the `resource:...` query terms."""

    @classmethod
    def handles_ast(cls, term_ast: qdsl.AST):
        return term_ast.qualifier.name == 'resource'

    def as_predicate(self, ctx):
        return pred.any(
            pred.RepoObject(data=pred.At('.**.resource', self._matchers_predicate(ctx))),
            pred.RepoResource(meta=pred.At('.resource', self._matchers_predicate(ctx)))
        )


QDSL_TERM_CLASSES = [ResourceTerm] + qdsl.DEFAULT_TERM_CLASSES
QDSL_MATCHER_CLASSES = qdsl.DEFAULT_MATCHER_CLASSES


@dataclass
class QueryDSL2PredicateParser(qdsl.QueryDSL2PredicateParser):
    term_classes: List[Type[qdsl.Term]] = field(default_factory=lambda: QDSL_TERM_CLASSES)
    matcher_classes: List[Type[qdsl.Matcher]] = field(default_factory=lambda: QDSL_MATCHER_CLASSES)
