
"""constant definitions"""
from typing import Dict


class HAL:
    """HAL representation keywords"""
    META = 'meta'
    DATA = 'data'
    ATTRIBUTES = 'attrs'
    UUID = 'uuid'
    LIBRARY = 'library'
    NAME = 'name'
    PARENT = 'parent'
    PATH = 'path'
    OBJECT = 'object'
    EMBEDDINGS = '_embeddings'
    MESSAGES = '_messages'
    LINKS = '_links'
    LINK_HREF = 'href'
    LINK_TYPE = 'type'
    JSON_REF = '$ref'
    ERROR = 'error'

    INFO_KEYWORDS = [MESSAGES, ERROR]
    GENERIC_KEYWORDS = [META, DATA, ATTRIBUTES, EMBEDDINGS, LINKS, ATTRIBUTES]
    LINK_KEYWORDS = [LINK_HREF, LINK_TYPE]
    OBJ_REF_KEYWORDS = [LINK_HREF, JSON_REF]


class URL_PARAM_KEYS:
    """Url parameter keywords"""
    DATA = 'data'
    LIBRARY = 'library'
    CASCADE_OBJECT = 'cascade_object'
    CASCADE_CHILDREN = 'cascade_children'
    LOG_LEVEL = 'level'
    ROLLBACK = 'rollback'
    AS_IMPORT = 'as_import'
    QUERY = 'q'
    KIND = 'kind'
    LIMIT = 'limit'
    OFFSET = 'offset'

    attr_doc: Dict[str, str] = dict()


URL_PARAM_KEYS.__doc__ = (URL_PARAM_KEYS.__doc__ or "") + "\nAttributes:"
for (key, doc) in [
    (URL_PARAM_KEYS.DATA, "If true, act on the data container related to the object or resource"),
    (URL_PARAM_KEYS.LIBRARY, "If specified, use this as the default library (overriding the tenants library)"),
    (URL_PARAM_KEYS.CASCADE_OBJECT, "Delete an object related to a resource if it would become orphaned"),
    (URL_PARAM_KEYS.CASCADE_CHILDREN, "Allow the operation to cascade to the children if needed (delete, move, ...)"),
    (URL_PARAM_KEYS.LOG_LEVEL, "Control the amount of messages you get returned in '_messages'"),
    (URL_PARAM_KEYS.ROLLBACK, "Rollback any the operation at the end of the request"),
    (URL_PARAM_KEYS.AS_IMPORT,
     "Create resources with audit attributes (user|timestamp-created|modified) as specified in the request."),
    (URL_PARAM_KEYS.QUERY, "Contains the query string that filters on (child) resources."),
    (URL_PARAM_KEYS.KIND, "Filter on the item kind returned."),
    (URL_PARAM_KEYS.LIMIT, "Paging: maximum number of items returned."),
    (URL_PARAM_KEYS.OFFSET, "Paging: number of items to skip before returning results.")
]:
    URL_PARAM_KEYS.attr_doc[key] = doc
    URL_PARAM_KEYS.__doc__ += f'\n  {key:15} {doc}'
